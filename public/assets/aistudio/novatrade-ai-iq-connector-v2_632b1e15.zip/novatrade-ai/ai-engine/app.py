from datetime import datetime, timezone
from typing import Literal
import numpy as np
from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI(title='NovaTrade AI Research Engine', version='0.1.0')

class AnalyseRequest(BaseModel):
    symbol: str = Field(default='EURUSD', pattern=r'^[A-Z0-9_-]{3,20}$')
    timeframe: Literal['1m','5m','15m'] = '1m'


def ema(values: np.ndarray, period: int) -> np.ndarray:
    alpha = 2 / (period + 1)
    out = np.empty_like(values, dtype=float)
    out[0] = values[0]
    for i in range(1, len(values)):
        out[i] = alpha * values[i] + (1 - alpha) * out[i - 1]
    return out


def rsi(values: np.ndarray, period: int = 14) -> float:
    delta = np.diff(values)
    gains = np.maximum(delta, 0)
    losses = np.maximum(-delta, 0)
    avg_gain = np.mean(gains[-period:])
    avg_loss = np.mean(losses[-period:])
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return float(100 - 100 / (1 + rs))

@app.get('/health')
def health():
    return {'status':'ok','engine':'rule-based research','live_data':False}

@app.post('/analyse/demo')
def analyse_demo(req: AnalyseRequest):
    # Synthetic candles are deliberately NOT used to create trade signals.
    # Until a real, documented market data adapter is configured, return WAIT.
    return {
        'signal': {
            'symbol': req.symbol,
            'direction': 'WAIT',
            'score': 0,
            'reasons': [
                'No verified market candle feed is connected.',
                'The engine refuses to invent prices or manufacture a trading signal.'
            ],
            'warning': 'NO LIVE DATA — WAIT. Connect a lawful, documented market-data provider before analysis.'
        },
        'source': 'no-market-data',
        'timestamp': datetime.now(timezone.utc).isoformat()
    }
