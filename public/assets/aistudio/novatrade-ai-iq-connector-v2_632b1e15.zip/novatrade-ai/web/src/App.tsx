import { useEffect, useState } from 'react';

type Signal = { symbol: string; direction: string; score: number; reasons: string[]; warning: string };
type Health = { status: string; mode: string; liveExecution: boolean };
type BrokerStatus = { broker: string; connected: boolean; executionEnabled: boolean; message: string };
const API = import.meta.env.VITE_API_URL || 'http://localhost:4000';

export default function App() {
  const [health, setHealth] = useState<Health | null>(null);
  const [broker, setBroker] = useState<BrokerStatus | null>(null);
  const [signal, setSignal] = useState<Signal | null>(null);
  const [mode, setMode] = useState('signals');
  const [amount, setAmount] = useState(100);
  const [dailyStop, setDailyStop] = useState(500);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [autoArmed, setAutoArmed] = useState(false);
  const [riskSummary, setRiskSummary] = useState('Risk guard active');

  useEffect(() => {
    fetch(`${API}/api/health`).then(r => r.json()).then(setHealth).catch(() => setHealth({status:'API offline',mode:'paper only',liveExecution:false}));
    fetch(`${API}/api/broker/status`).then(r => r.json()).then(setBroker).catch(() => setBroker({broker:'IQ Option',connected:false,executionEnabled:false,message:'Broker status unavailable.'}));
    fetch(`${API}/api/auto-paper/status`).then(r => r.json()).then(d => { setAutoArmed(Boolean(d.armed)); setRiskSummary(d.risk?.allowed ? 'Risk limits clear' : (d.risk?.reasons || ['Risk guard active']).join(' ')); }).catch(() => setRiskSummary('API unavailable')); 
  }, []);

  async function analyse() {
    setLoading(true); setMessage('');
    try {
      const r = await fetch(`${API}/api/signals/demo`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({symbol:'EURUSD', timeframe:'1m'}) });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Analysis failed');
      setSignal(data.signal);
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Could not reach the API.'); }
    finally { setLoading(false); }
  }


  async function toggleAutoPaper() {
    setLoading(true); setMessage('');
    try {
      const r = await fetch(`${API}/api/auto-paper/arm`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({enabled:!autoArmed})});
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Could not change automatic paper mode');
      setAutoArmed(Boolean(data.armed));
      setMessage(data.notice || (data.armed ? 'Automatic paper mode armed.' : 'Automatic paper mode paused.'));
    } catch(e) { setMessage(e instanceof Error ? e.message : 'Automatic paper mode unavailable.'); }
    finally { setLoading(false); }
  }

  async function evaluateAutoPaper() {
    setLoading(true); setMessage('');
    try {
      const r = await fetch(`${API}/api/auto-paper/evaluate`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({symbol:'EURUSD',timeframe:'1m'})});
      const data = await r.json();
      if (!r.ok) throw new Error(data.reason || data.error || 'Evaluation failed');
      setMessage(data.entered ? `Paper trade simulated: ${data.trade.direction} ${data.trade.symbol} · ₦${data.trade.amount}.` : data.reason);
    } catch(e) { setMessage(e instanceof Error ? e.message : 'Automatic evaluation failed.'); }
    finally { setLoading(false); }
  }

  async function paperTrade() {
    if (!signal || signal.direction === 'WAIT') return;
    setLoading(true); setMessage('');
    try {
      const r = await fetch(`${API}/api/paper-trades`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({symbol:signal.symbol,direction:signal.direction,amount,dailyLossLimit:dailyStop})});
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Paper trade rejected');
      setMessage(`Paper trade recorded: ${data.trade.direction} ${data.trade.symbol} — simulated only.`);
    } catch(e) { setMessage(e instanceof Error ? e.message : 'Paper trade failed.'); }
    finally { setLoading(false); }
  }

  return <main className="shell">
    <header className="topbar"><div className="brand"><div className="logo">N</div><div><b>NOVATRADE <span>AI</span></b><small>INTELLIGENT TRADING WORKSPACE</small></div></div><div className="status"><i/> {health?.status === 'ok' ? 'SYSTEM ONLINE' : health?.status?.toUpperCase() || 'CONNECTING'}</div></header>
    <section className="hero"><div><div className="eyebrow">YOUR MARKET RESEARCH COMMAND CENTRE</div><h1>Trade with <em>intelligence.</em></h1><p>Analyse opportunities, test strategies and manage risk from one workspace.</p><div className="notice">DEMO / PAPER MODE ONLY <span>• Live broker execution is disabled</span></div></div><div className="orb"><div className="orb-inner">N<span>AI</span></div></div></section>
    <section className="stats"><article><small>ACCOUNT MODE</small><strong>Paper / Demo</strong><label>No real funds are used</label></article><article><small>IQ OPTION</small><strong className="off">Not connected</strong><label>Authorised API not verified</label></article><article><small>ACTIVE STRATEGY</small><strong>Multi-indicator</strong><label>Rule-based research v0.1</label></article><article><small>RISK STATUS</small><strong className="good">Protected</strong><label>Limits checked before simulation</label></article></section>
    <section className="brokerbar"><div><div className="eyebrow">BROKER CONNECTION</div><b>IQ Option · {broker?.connected ? 'Connected' : 'Not connected'}</b><p>{broker?.message || 'Checking broker integration status…'}</p></div><span className="locked">REAL ACCOUNT EXECUTION LOCKED</span></section>
    <section className="grid"><div className="panel mainpanel"><div className="panelhead"><div><div className="eyebrow">AI INTELLIGENCE ENGINE</div><h2>Market analysis</h2></div><span className="tag">RESEARCH MODE</span></div><div className="assetrow"><div><small>SELECTED MARKET</small><h3>EUR / USD</h3></div><div className="timeframe">TIMEFRAME <b>1 MIN</b></div></div><div className="analysisbox">{signal ? <><div className="signalrow"><div><small>ENGINE OUTPUT</small><h2 className={signal.direction==='WAIT'?'neutral':signal.direction==='CALL'?'up':'down'}>{signal.direction}</h2></div><div className="score"><strong>{signal.score}/100</strong><small>RULE SCORE · NOT WIN PROBABILITY</small></div></div><ul>{signal.reasons.map((r,i)=><li key={i}>{r}</li>)}</ul><p className="warning">{signal.warning}</p></> : <div className="empty"><div className="pulse">✦</div><b>Ready to analyse</b><span>Run the engine to evaluate a sample market series.</span></div>}</div><button className="primary" disabled={loading} onClick={analyse}>{loading?'ANALYSING…':'✦  ANALYSE MARKET'}</button>{message && <p className="message">{message}</p>}</div>
    <div className="panel controls"><div className="eyebrow">CONTROL CENTRE</div><h2>Trading preferences</h2><label className="fieldlabel">OPERATING MODE</label><div className="modes">{[['signals','Signals'],['assisted','Assisted'],['auto','Automatic']].map(([v,l])=><button key={v} className={mode===v?'selected':''} onClick={()=>setMode(v)}>{l}</button>)}</div><p className="hint">All three modes are represented. Automatic mode currently operates in paper simulation only; real broker execution remains locked until an authorised integration is verified.</p><div className="safety"><b>Automatic paper mode: {autoArmed ? 'ARMED' : 'PAUSED'}</b><span>{riskSummary}. It will only consider an order when verified market data and a valid analysis signal are available.</span><div className="actionrow"><button className="secondary" disabled={loading} onClick={toggleAutoPaper}>{autoArmed ? 'PAUSE AUTO MODE' : 'ARM AUTO MODE'}</button><button className="secondary" disabled={loading || !autoArmed} onClick={evaluateAutoPaper}>RUN AI CHECK</button></div></div><label className="fieldlabel" htmlFor="amount">PAPER TRADE AMOUNT (₦)</label><input id="amount" type="number" min="1" max="100000" value={amount} onChange={e=>setAmount(Math.max(1,Number(e.target.value)))}/><label className="fieldlabel" htmlFor="stop">DAILY SIMULATED LOSS LIMIT (₦)</label><input id="stop" type="number" min="1" max="1000000" value={dailyStop} onChange={e=>setDailyStop(Math.max(1,Number(e.target.value)))}/><button className="secondary" disabled={loading || !signal || signal.direction==='WAIT'} onClick={paperTrade}>RECORD PAPER TRADE</button><div className="safety"><b>Real account protection</b><span>Real-account login and automatic order execution are not available in this build. Never enter broker passwords, OTPs, cookies or session tokens here.</span></div><div className="safety"><b>Capital protection</b><span>Trade sizes and daily limits are checked by the server. Paper trades are not real executions or evidence of profitability.</span></div></div></section>
    <footer>NovaTrade AI · Broker integration foundation <span>Not affiliated with IQ Option · Trading involves substantial risk.</span></footer>
  </main>;
}
