import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { z } from 'zod';
import { IQOptionAdapter } from './brokers/iqOption.js';

const app = express();
app.use(cors({ origin: process.env.WEB_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '100kb' }));
const port = Number(process.env.PORT || 4000);
type PaperTrade = {id:string;symbol:string;direction:string;amount:number;status:string;createdAt:string};
const paperTrades: PaperTrade[] = [];
const iqOption = new IQOptionAdapter();
const riskSettings = { maxTradeAmount: 100, dailyLossLimit: 500, dailyProfitTarget: 500, maxConsecutiveLosses: 3 };
let autoPaperArmed = false;
let consecutiveLosses = 0;
let simulatedDailyLoss = 0;
let simulatedDailyProfit = 0;
let dailyKey = new Date().toISOString().slice(0, 10);
function rollPaperDay() {
  const today = new Date().toISOString().slice(0, 10);
  if (today !== dailyKey) { dailyKey = today; consecutiveLosses = 0; simulatedDailyLoss = 0; simulatedDailyProfit = 0; autoPaperArmed = false; }
}
function riskStatus() {
  rollPaperDay();
  const reasons: string[] = [];
  if (simulatedDailyLoss >= riskSettings.dailyLossLimit) reasons.push('Daily loss limit reached.');
  if (simulatedDailyProfit >= riskSettings.dailyProfitTarget) reasons.push('Daily profit target reached.');
  if (consecutiveLosses >= riskSettings.maxConsecutiveLosses) reasons.push('Maximum consecutive losses reached.');
  return { allowed: reasons.length === 0, reasons, simulatedDailyLoss, simulatedDailyProfit, consecutiveLosses, limits: riskSettings };
}

app.get('/api/health', (_req,res) => res.json({status:'ok',mode:'paper only',liveExecution:false,version:'0.1.0'}));

app.post('/api/signals/demo', async (req,res) => {
  const schema = z.object({symbol:z.string().regex(/^[A-Z0-9_-]{3,20}$/).default('EURUSD'),timeframe:z.enum(['1m','5m','15m']).default('1m')});
  const parsed = schema.safeParse(req.body ?? {});
  if (!parsed.success) return res.status(400).json({error:'Invalid symbol or timeframe.'});
  const engine = process.env.AI_ENGINE_URL;
  if (engine) {
    try {
      const response = await fetch(`${engine}/analyse/demo`, {method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(parsed.data)});
      if (response.ok) return res.json(await response.json());
    } catch { /* transparent fallback below */ }
  }
  // Clearly labelled deterministic demo output. Not connected to a live market.
  const signal = {symbol:parsed.data.symbol,direction:'WAIT',score:0,reasons:['No market-data provider is configured.','No live or historical candles were supplied.'],warning:'DEMO PLACEHOLDER — this is not a market signal. Connect a documented market-data source before using analysis.'};
  return res.json({signal,source:'placeholder',timestamp:new Date().toISOString()});
});

app.post('/api/paper-trades', (req,res) => {
  const schema = z.object({symbol:z.string().regex(/^[A-Z0-9_-]{3,20}$/),direction:z.enum(['CALL','PUT']),amount:z.number().positive().max(100000),dailyLossLimit:z.number().positive().max(1000000)});
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:'Invalid paper trade request.'});
  const currentRisk = riskStatus();
  if (!currentRisk.allowed) return res.status(409).json({error:'Risk guard blocked this paper trade.', risk:currentRisk});
  if (parsed.data.amount > riskSettings.maxTradeAmount || parsed.data.amount > riskSettings.dailyLossLimit - simulatedDailyLoss) return res.status(400).json({error:'Paper trade amount exceeds the configured per-trade or remaining daily risk limit.'});
  const trade = {id:crypto.randomUUID(),symbol:parsed.data.symbol,direction:parsed.data.direction,amount:parsed.data.amount,status:'SIMULATED_NOT_EXECUTED',createdAt:new Date().toISOString()};
  paperTrades.unshift(trade);
  return res.status(201).json({trade,notice:'Simulation only. No broker order was sent.'});
});

app.get('/api/paper-trades', (_req,res) => res.json({trades:paperTrades}));

app.get('/api/risk/status', (_req,res) => res.json(riskStatus()));
app.put('/api/risk/settings', (req,res) => {
  const schema = z.object({
    maxTradeAmount: z.number().positive().max(100000),
    dailyLossLimit: z.number().positive().max(1000000),
    dailyProfitTarget: z.number().positive().max(1000000),
    maxConsecutiveLosses: z.number().int().min(1).max(20),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:'Invalid risk settings.'});
  Object.assign(riskSettings, parsed.data);
  return res.json({settings:riskSettings, status:riskStatus()});
});
app.post('/api/auto-paper/arm', (req,res) => {
  const enabled = z.object({enabled:z.boolean()}).safeParse(req.body);
  if (!enabled.success) return res.status(400).json({error:'Provide enabled: true or false.'});
  if (enabled.data.enabled) {
    const risk = riskStatus();
    if (!risk.allowed) return res.status(409).json({armed:false,error:'Risk guard prevents arming.',risk});
    autoPaperArmed = true;
  } else autoPaperArmed = false;
  return res.json({armed:autoPaperArmed, notice:'Paper mode only. This control cannot place real broker orders.'});
});
app.get('/api/auto-paper/status', (_req,res) => res.json({armed:autoPaperArmed, risk:riskStatus(), execution:'PAPER_ONLY'}));
app.post('/api/auto-paper/evaluate', async (req,res) => {
  if (!autoPaperArmed) return res.status(409).json({entered:false,reason:'Automatic paper mode is not armed.'});
  const schema = z.object({symbol:z.string().regex(/^[A-Z0-9_-]{3,20}$/).default('EURUSD'),timeframe:z.enum(['1m','5m','15m']).default('1m')});
  const parsed = schema.safeParse(req.body ?? {});
  if (!parsed.success) return res.status(400).json({error:'Invalid market request.'});
  const risk = riskStatus();
  if (!risk.allowed) { autoPaperArmed = false; return res.status(409).json({entered:false,reason:'Risk guard stopped automatic paper trading.',risk}); }
  const engine = process.env.AI_ENGINE_URL;
  if (!engine) return res.json({entered:false,reason:'No verified market-data and analysis service is configured. AI decision: WAIT.',source:'no-market-data'});
  try {
    const response = await fetch(`${engine}/analyse/demo`, {method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(parsed.data)});
    if (!response.ok) return res.status(502).json({entered:false,reason:'Analysis service unavailable.'});
    const analysis:any = await response.json();
    const direction = analysis?.signal?.direction;
    if (direction !== 'CALL' && direction !== 'PUT') return res.json({entered:false,reason:'AI decision is WAIT. No paper trade opened.',analysis});
    const amount = Math.min(riskSettings.maxTradeAmount, riskSettings.dailyLossLimit - simulatedDailyLoss);
    if (amount <= 0) { autoPaperArmed = false; return res.status(409).json({entered:false,reason:'No risk budget remains.'}); }
    const trade:PaperTrade = {id:crypto.randomUUID(),symbol:parsed.data.symbol,direction,amount,status:'SIMULATED_PENDING_OUTCOME',createdAt:new Date().toISOString()};
    paperTrades.unshift(trade);
    return res.status(201).json({entered:true,trade,analysis,notice:'Paper simulation only. No broker order was sent.'});
  } catch { return res.status(502).json({entered:false,reason:'Could not reach the analysis service.'}); }
});
app.post('/api/paper-trades/:id/settle', (req,res) => {
  const schema = z.object({outcome:z.enum(['win','loss']),pnl:z.number().positive().max(100000)});
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:'Provide outcome and a positive simulated P&L.'});
  const trade = paperTrades.find(t => t.id === req.params.id);
  if (!trade || trade.status !== 'SIMULATED_PENDING_OUTCOME') return res.status(404).json({error:'Pending paper trade not found.'});
  if (parsed.data.outcome === 'loss' && parsed.data.pnl > trade.amount) return res.status(400).json({error:'Simulated loss cannot exceed trade amount.'});
  trade.status = parsed.data.outcome === 'win' ? 'SIMULATED_WIN' : 'SIMULATED_LOSS';
  if (parsed.data.outcome === 'win') { simulatedDailyProfit += parsed.data.pnl; consecutiveLosses = 0; }
  else { simulatedDailyLoss += parsed.data.pnl; consecutiveLosses += 1; }
  const risk = riskStatus();
  if (!risk.allowed) autoPaperArmed = false;
  return res.json({trade,risk,autoPaperArmed,notice:'Simulated settlement only; this is not a broker-confirmed result.'});
});
app.get('/api/broker/status', async (_req,res) => {
  const capabilities = await iqOption.getCapabilities();
  return res.json({ ...capabilities, connected: false, executionEnabled: false });
});

// Deliberately fail closed: live execution cannot be enabled without a verified,
// documented broker adapter. This prevents UI toggles from ever placing real orders.
app.post('/api/live-trading/enable', async (_req,res) => {
  const capabilities = await iqOption.getCapabilities();
  if (!capabilities.authorisedApiVerified || !capabilities.orderExecutionSupported) {
    return res.status(409).json({
      enabled: false,
      error: 'Live trading is locked. A documented, authorised broker API and verified account eligibility are required first.',
      broker: capabilities.broker,
    });
  }
  return res.status(501).json({ enabled: false, error: 'Live execution adapter is not implemented.' });
});

app.post('/api/live-trades', (_req,res) => res.status(403).json({
  executed: false,
  error: 'Live order execution is disabled. No broker order was sent.',
}));

app.listen(port, () => console.log(`NovaTrade API listening on http://localhost:${port}`));
