/** Broker adapter contract. Implement only against a broker-documented, authorised API. */
export type BrokerEnvironment = 'demo' | 'real';
export type BrokerCapabilities = {
  broker: string;
  adapterInstalled: boolean;
  authorisedApiVerified: boolean;
  demoSupported: boolean;
  realAccountSupported: boolean;
  orderExecutionSupported: boolean;
  environment: BrokerEnvironment | null;
  message: string;
};

export interface BrokerAdapter {
  readonly brokerName: string;
  getCapabilities(): Promise<BrokerCapabilities>;
  // Implementations must validate account, asset, amount, expiry and risk server-side.
  // Do not accept passwords, OTPs, browser cookies or session tokens from the frontend.
  placeOrder?(_input: {
    environment: BrokerEnvironment;
    symbol: string;
    direction: 'CALL' | 'PUT';
    amount: number;
    expirySeconds: number;
    idempotencyKey: string;
  }): Promise<{ brokerOrderId: string; status: string }>;
}
