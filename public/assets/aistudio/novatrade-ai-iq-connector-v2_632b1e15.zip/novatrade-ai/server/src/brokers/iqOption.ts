import type { BrokerAdapter, BrokerCapabilities } from './types.js';

/**
 * IQ Option integration placeholder.
 * IQ Option has no publicly documented retail trading API available to this app.
 * Do not reverse engineer private endpoints or collect account passwords/session data.
 * Replace this adapter only after obtaining a documented, authorised integration and
 * confirming the user's account/jurisdiction eligibility with the broker.
 */
export class IQOptionAdapter implements BrokerAdapter {
  readonly brokerName = 'IQ Option';

  async getCapabilities(): Promise<BrokerCapabilities> {
    return {
      broker: this.brokerName,
      adapterInstalled: false,
      authorisedApiVerified: false,
      demoSupported: false,
      realAccountSupported: false,
      orderExecutionSupported: false,
      environment: null,
      message: 'Not connected. An authorised, documented broker API and account eligibility confirmation are required. No login credentials are collected.',
    };
  }
}
