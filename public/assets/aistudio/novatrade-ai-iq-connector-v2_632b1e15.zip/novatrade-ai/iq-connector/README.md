# IQ Option experimental connector (PRACTICE / read-only)

This is a functional integration *implementation*, not a verified live connection. It has **not** been authenticated against your account. It uses the community-maintained `iqoptionapi` Python package, which is unofficial and warns against use with real funds. Review the dependency before installing; some forks disable TLS certificate verification. Do not expose this service to the internet.

## Local run

1. Create a Python virtual environment.
2. `pip install -r requirements.txt`
3. Review and install a compatible `iqoptionapi` fork from its source repository in your private environment.
4. Set `IQ_EMAIL` and `IQ_PASSWORD` as environment variables on your own machine; never send them in chat or put them in frontend code.
5. `uvicorn app:app --host 127.0.0.1 --port 8010`
6. `GET http://127.0.0.1:8010/health` then `POST http://127.0.0.1:8010/connect`.
7. `GET /balance` and `POST /candles` with JSON `{"symbol":"EURUSD","interval":60,"count":50}`.

The service forces PRACTICE mode before balance and candle requests, and has no trade-order route. It does not implement a secure public web login. It does not guarantee broker compatibility. Real-money trading remains disabled until a reviewed, reliable, authorised connection and risk controls are verified.
