"""Experimental, self-hosted IQ Option read-only connector.
Credentials are read from local environment, never accepted over HTTP.
This service does not place orders or switch to REAL.
"""
import os
import time
import threading
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title='NovaTrade IQ Option experimental connector', version='0.2.0')
_lock = threading.RLock()
_client = None
_last_error = None

class CandlesQuery(BaseModel):
    symbol: str = Field(default='EURUSD', pattern=r'^[A-Z0-9_-]{3,25}$')
    interval: int = Field(default=60, ge=5, le=3600)
    count: int = Field(default=50, ge=1, le=200)

def connect():
    global _client, _last_error
    with _lock:
        if _client is not None:
            try:
                if _client.check_connect():
                    return _client
            except Exception:
                _client = None
        email = os.environ.get('IQ_EMAIL')
        password = os.environ.get('IQ_PASSWORD')
        if not email or not password:
            raise HTTPException(503, 'IQ_EMAIL and IQ_PASSWORD must be set on the private connector host.')
        try:
            from iqoptionapi.stable_api import IQ_Option
            client = IQ_Option(email, password)
            result = client.connect()
            if not result or not result[0]:
                raise RuntimeError('Broker authentication failed or requires additional verification.')
            client.change_balance('PRACTICE')
            _client = client
            _last_error = None
            return client
        except Exception as exc:
            _last_error = type(exc).__name__
            raise HTTPException(502, f'Broker connection failed ({_last_error}); check connector logs locally.') from None

@app.get('/health')
def health():
    return {'status':'running', 'mode':'PRACTICE_READ_ONLY', 'realTradingEnabled':False, 'credentialsConfigured':bool(os.getenv('IQ_EMAIL') and os.getenv('IQ_PASSWORD'))}

@app.post('/connect')
def connect_route():
    client = connect()
    return {'connected':bool(client.check_connect()), 'mode':'PRACTICE', 'realTradingEnabled':False}

@app.get('/balance')
def balance():
    with _lock:
        client = connect()
        client.change_balance('PRACTICE')
        return {'balance':client.get_balance(), 'mode':'PRACTICE', 'source':'IQ_OPTION_UNOFFICIAL'}

@app.post('/candles')
def candles(query: CandlesQuery):
    with _lock:
        client = connect()
        client.change_balance('PRACTICE')
        rows = client.get_candles(query.symbol, query.interval, query.count, int(time.time()))
        if not isinstance(rows, list):
            raise HTTPException(502, 'Broker did not return valid candles.')
        return {'symbol':query.symbol, 'interval':query.interval, 'candles':rows, 'source':'IQ_OPTION_UNOFFICIAL', 'note':'Historical candles may be delayed; not suitable for latency-sensitive execution.'}

@app.post('/disconnect')
def disconnect():
    global _client
    with _lock:
        _client = None
    return {'connected':False}
