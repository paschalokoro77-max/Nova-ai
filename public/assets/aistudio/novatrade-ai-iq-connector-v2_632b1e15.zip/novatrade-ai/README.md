# NovaTrade AI — broker integration foundation

NovaTrade AI is a mobile-friendly trading research workspace with a Node/Express API, a Python analysis service, a Supabase schema starter and paper-trading records. This build includes an IQ Option broker-adapter boundary, but **does not connect to IQ Option or execute real orders**.

## What is included
- React + TypeScript responsive dashboard.
- Three operating-mode selections: Signals, Assisted and Automatic. Automatic mode can be armed for paper simulation only.
- Node/Express API for health, analysis proxy, paper trades, broker status and server-side risk checks.
- Automatic paper-mode arm/pause and evaluation endpoints. The engine refuses to invent a signal when verified market data is missing.
- Daily simulated loss/profit stops and consecutive-loss stop. These starter settings are in-memory and reset when the API restarts; they are not production persistence.
- Python FastAPI analysis-engine stub that returns WAIT until verified market candles are supplied.
- Supabase schema starter with row-level security.
- IQ Option adapter contract and a fail-closed placeholder.
- Server endpoints that explicitly refuse live trading while no authorised adapter is installed.

## Why IQ Option live login is not implemented
IQ Option does not provide this project with a publicly documented retail API for third-party login and order execution. Community reverse-engineered libraries may break, expose credentials/session tokens, or conflict with broker rules. This project therefore does not collect IQ Option passwords, OTPs, cookies or session tokens and does not automate the broker website. A real connector can only be implemented after obtaining a documented, authorised API/integration and confirming the account and jurisdiction are eligible.

The public IQ Option website has also displayed country-specific availability restrictions. Confirm directly with IQ Option that your own account is eligible before attempting any connection. Do not use a VPN or false location details to bypass broker restrictions.

## Run locally

### Requirements
- Node.js 20+
- Python 3.11+
- Supabase project (optional for the local starter)

### 1. API
```bash
cd server
cp .env.example .env
npm install
npm run dev
```
API: `http://localhost:4000`

### 2. Web app
```bash
cd web
npm install
npm run dev
```

### 3. Python analysis engine
```bash
cd ai-engine
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Set `AI_ENGINE_URL=http://localhost:8000` in `server/.env`.

## API endpoints
- `GET /api/health` — service status.
- `POST /api/signals/demo` — returns WAIT unless a real data-backed analysis service is configured.
- `POST /api/paper-trades` — records a simulation only.
- `GET /api/paper-trades` — paper trade journal.
- `GET /api/broker/status` — broker adapter capability status.
- `GET /api/risk/status` and `PUT /api/risk/settings` — paper risk limits and status.
- `POST /api/auto-paper/arm` and `GET /api/auto-paper/status` — arm/pause and inspect paper auto mode.
- `POST /api/auto-paper/evaluate` — ask the engine for a data-backed decision; only CALL/PUT from a configured analysis service can create a paper record.
- `POST /api/paper-trades/:id/settle` — record a simulated outcome for testing risk stops.
- `POST /api/live-trading/enable` — fails closed until an authorised adapter is verified.
- `POST /api/live-trades` — refuses live order execution in this build.

## Before production
1. Add user authentication, session management, rate limits and audit logging. Do not expose this starter API publicly before these controls exist.
2. Connect a lawful, documented market-data source; display source, timestamps and stale-feed status.
3. Add historical replay and walk-forward testing; report sample size, expectancy, drawdown and confidence intervals.
4. Obtain broker documentation and written authorisation for any broker adapter. IQ Option connection and real-account execution remain unimplemented in this package; there is no credential form or private-endpoint workaround.
5. Implement server-side order validation, idempotency, balance checks, exposure limits, kill switch and reconciliation.
6. Confirm legal/regulatory requirements and the user's broker account eligibility in their jurisdiction.
7. Security review, automated tests, deployment hardening and monitoring.

## Risk notice
No trading system can guarantee a 100% win rate or reliable weekly income. A model score is not a probability of winning. Binary options and leveraged trading can result in rapid loss of capital. Paper results do not establish real-money profitability.

## Experimental IQ Option connectivity probe

See `connector/README.md`. A local, read-only IQ Option community-library probe is included. It can attempt login, read a selected account balance and fetch recent candles, but **has not been verified against IQ Option servers**. No real or demo broker orders are sent by this probe. The main website remains disconnected until verified integration is completed.

## Experimental IQ Option connector (new)
See `iq-connector/README.md` for a self-hosted **PRACTICE/read-only** implementation with connect, balance, and candle endpoints. It is not yet authenticated or tested against a live broker account. Do not expose the connector to the public internet. Real-money execution is intentionally not enabled.
