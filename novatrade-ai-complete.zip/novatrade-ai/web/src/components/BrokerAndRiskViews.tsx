import { useEffect, useState, type FormEvent } from 'react';
import {
  AlertTriangle,
  Check,
  LogOut,
  Moon,
  RefreshCw,
  ShieldCheck,
  Sun,
  Unplug,
} from 'lucide-react';
import type {
  ActivityEvent,
  AiSettings,
  AssetDefinition,
  BrokerCatalogItem,
  BrokerStatusSnapshot,
  RiskSettings,
  RiskStatus,
  Timeframe,
  UserProfile,
} from '../types';
import { isSupabaseConfigured, updateSupabaseProfile } from '../lib/supabase';

const glassCard =
  'rounded-2xl border border-slate-200 dark:border-indigo-500/20 bg-white/95 dark:bg-[#0E1629]/85 backdrop-blur-md shadow-sm';

interface BrokersViewProps {
  broker: BrokerStatusSnapshot | null;
  catalog: BrokerCatalogItem[];
  busy: boolean;
  onRefresh: () => void;
  onConnectIq: () => void;
  onDisconnectIq: () => void;
  onFetchIqAssets: () => Promise<Array<{ symbol: string; category: string; open: boolean }>>;
  onFetchIqHistory: () => Promise<{ supported: boolean; trades: Array<Record<string, unknown>>; note: string }>;
}

export function BrokerConnectionsView({
  broker,
  catalog,
  busy,
  onRefresh,
  onConnectIq,
  onDisconnectIq,
  onFetchIqAssets,
  onFetchIqHistory,
}: BrokersViewProps) {
  const [iqAssets, setIqAssets] = useState<Array<{ symbol: string; category: string; open: boolean }> | null>(null);
  const [iqHistory, setIqHistory] = useState<{ supported: boolean; trades: Array<Record<string, unknown>>; note: string } | null>(null);
  const [diagError, setDiagError] = useState<string | null>(null);

  async function handleInspectAssets() {
    setDiagError(null);
    try {
      const list = await onFetchIqAssets();
      setIqAssets(list);
    } catch (err) {
      setDiagError(err instanceof Error ? err.message : 'Failed to fetch IQ assets.');
    }
  }

  async function handleInspectHistory() {
    setDiagError(null);
    try {
      const hist = await onFetchIqHistory();
      setIqHistory(hist);
    } catch (err) {
      setDiagError(err instanceof Error ? err.message : 'Failed to fetch IQ history.');
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-900 dark:text-white">Broker Connections</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            IQ Option adapter bridged to <code className="font-mono text-slate-700 dark:text-slate-300">IQ_CONNECTOR_URL</code> (PRACTICE read-only). Binary options contracts are exposed only when an authorised broker session confirms open instruments.
          </p>
        </div>
        <button
          type="button"
          onClick={onRefresh}
          disabled={busy}
          className="min-h-10 inline-flex items-center gap-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#0E1629] hover:bg-slate-50 dark:hover:bg-slate-800 px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${busy ? 'animate-spin' : ''}`} /> Refresh Status
        </button>
      </div>

      <div className={`${glassCard} p-5 space-y-4`}>
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Primary Broker · IQ Option</p>
            <h3 className="mt-1 text-lg font-semibold text-slate-900 dark:text-white">
              {broker?.connected ? 'Connected (PRACTICE Read-Only)' : 'Not Connected'}
            </h3>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 max-w-2xl">{broker?.message}</p>
          </div>
          <span className="rounded-lg border border-amber-400/50 dark:border-amber-700/60 bg-amber-50 dark:bg-amber-950/40 px-3 py-1.5 text-xs font-medium text-amber-800 dark:text-amber-300 whitespace-nowrap">
            Real-Money Execution Disabled
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-200 dark:border-slate-800">
          <div>
            <p className="text-[11px] text-slate-500">Connector URL</p>
            <p className="mt-1 text-xs font-medium text-slate-800 dark:text-slate-200">
              {broker?.diagnostics?.urlValid
                ? `Valid (${broker.diagnostics.targetHost || 'Configured'})`
                : broker?.connectorUrlConfigured
                  ? 'Invalid Format'
                  : 'Not Configured'}
            </p>
          </div>
          <div>
            <p className="text-[11px] text-slate-500">Health &amp; Reachability</p>
            <p className="mt-1 text-xs font-medium text-slate-800 dark:text-slate-200">
              {broker?.diagnostics?.reachable
                ? `Reachable (${broker.diagnostics.latencyMs ?? 0}ms)`
                : broker?.connectorUrlConfigured
                  ? 'Unreachable'
                  : 'Standby'}
            </p>
          </div>
          <div>
            <p className="text-[11px] text-slate-500">Practice Balance</p>
            <p className="mt-1 text-xs font-mono tabular-nums text-slate-800 dark:text-slate-200">
              {broker?.balance != null ? `${broker.balance.toFixed(2)} ${broker.currency || ''}` : '—'}
            </p>
          </div>
          <div>
            <p className="text-[11px] text-slate-500">Order Execution</p>
            <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">Locked (Fail-Closed)</p>
          </div>
        </div>

        {broker?.diagnostics && (
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#070B14] p-3 text-xs space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500 dark:text-slate-400">
              <span>
                Account Type: <strong className="text-slate-800 dark:text-slate-200">{broker.accountType || 'Unavailable'}</strong>
              </span>
              <span>
                Connector Auth Token:{' '}
                <strong className="text-slate-800 dark:text-slate-200">
                  {broker.diagnostics.tokenConfigured ? 'Set (Hidden)' : 'Not Set'}
                </strong>
              </span>
              <span>
                Remote Credentials:{' '}
                <strong className="text-slate-800 dark:text-slate-200">
                  {broker.diagnostics.credentialsConfigured === null
                    ? 'Unknown (Connector Offline)'
                    : broker.diagnostics.credentialsConfigured
                      ? 'Configured on Connector'
                      : 'Missing on Connector'}
                </strong>
              </span>
            </div>

            {broker.diagnostics.warnings.length > 0 && (
              <div className="space-y-1.5 pt-1">
                {broker.diagnostics.warnings.map((w, idx) => (
                  <p
                    key={idx}
                    className="rounded-lg border border-amber-300 dark:border-amber-800/70 bg-amber-50 dark:bg-amber-950/35 px-2.5 py-1.5 text-amber-800 dark:text-amber-300"
                  >
                    {w}
                  </p>
                ))}
              </div>
            )}

            {broker.diagnostics.lastConnectorError && (
              <p className="text-[11px] text-red-600 dark:text-red-400">
                Last diagnostic error: {broker.diagnostics.lastConnectorError}
              </p>
            )}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2 pt-2">
          <button
            type="button"
            disabled={busy || !broker?.diagnostics?.urlValid}
            onClick={onConnectIq}
            className="min-h-10 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-40 px-4 py-2 text-xs font-medium text-white whitespace-nowrap"
          >
            Connect Practice Session
          </button>
          <button
            type="button"
            disabled={busy || !broker?.connected}
            onClick={onDisconnectIq}
            className="min-h-10 inline-flex items-center gap-1.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40 px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap"
          >
            <Unplug className="h-3.5 w-3.5" /> Disconnect
          </button>
          <button
            type="button"
            disabled={busy || !broker?.connected}
            onClick={handleInspectAssets}
            className="min-h-10 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40 px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap"
          >
            Fetch Open Assets
          </button>
          <button
            type="button"
            disabled={busy || !broker?.connected}
            onClick={handleInspectHistory}
            className="min-h-10 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40 px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap"
          >
            Fetch Trade History
          </button>
        </div>

        {diagError && (
          <p className="rounded-xl border border-red-300 dark:border-red-900/60 bg-red-50 dark:bg-red-950/40 px-3 py-2 text-xs text-red-700 dark:text-red-300">{diagError}</p>
        )}

        {iqAssets && (
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#070B14] p-3 text-xs">
            <p className="font-medium text-slate-800 dark:text-slate-200 mb-2">Open IQ Option Assets ({iqAssets.length})</p>
            <div className="flex flex-wrap gap-2 text-slate-600 dark:text-slate-400">
              {iqAssets.slice(0, 24).map((a) => (
                <span key={`${a.category}:${a.symbol}`}>
                  {a.symbol} ({a.category})
                </span>
              ))}
            </div>
          </div>
        )}

        {iqHistory && (
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#070B14] p-3 text-xs text-slate-600 dark:text-slate-300">
            <p className="font-medium text-slate-900 dark:text-slate-200">IQ Option Trade History</p>
            <p className="mt-1 text-slate-500 dark:text-slate-400">
              {iqHistory.note} · Entries returned: {iqHistory.trades.length}
            </p>
          </div>
        )}

        <div className="border-t border-slate-200 dark:border-slate-800 pt-3">
          <p className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">Documented Connector Limitations</p>
          <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-400 list-disc pl-5">
            {(broker?.limitations || []).map((item, i) => (
              <li key={i}>{item}</li>
            ))}
          </ul>
        </div>
      </div>

      <div className={`${glassCard} p-5`}>
        <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3">Extensible Broker Architecture</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {catalog.map((item) => (
            <div key={item.id} className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#070B14] p-4">
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-semibold text-slate-900 dark:text-white">{item.name}</span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  {item.status === 'INTEGRATED_READONLY' ? 'Read-Only Adapter' : 'Adapter Slot'}
                </span>
              </div>
              <p className="mt-2 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

interface RiskProps {
  riskStatus: RiskStatus | null;
  busy: boolean;
  onSaveRisk: (settings: RiskSettings) => Promise<void>;
  onRequestEmergencyStop: (engaged: boolean) => void;
  onRequestResetDaily: () => void;
}

export function RiskManagementView({
  riskStatus,
  busy,
  onSaveRisk,
  onRequestEmergencyStop,
  onRequestResetDaily,
}: RiskProps) {
  const initial = riskStatus?.limits;
  const [form, setForm] = useState<RiskSettings>(
    initial || {
      maxTradeAmount: 100,
      dailyLossLimit: 500,
      dailyProfitTarget: 500,
      maxConsecutiveLosses: 3,
      maxDailyTrades: 25,
      maxSimultaneousTrades: 3,
      tradingScheduleEnabled: false,
      tradingStartHourUtc: 7,
      tradingEndHourUtc: 20,
      emergencyStop: false,
    }
  );
  const [savedMsg, setSavedMsg] = useState<string | null>(null);

  useEffect(() => {
    if (riskStatus?.limits) {
      setForm(riskStatus.limits);
    }
  }, [riskStatus?.limits]);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSavedMsg(null);
    await onSaveRisk(form);
    setSavedMsg('Risk limits saved and enforced server-side.');
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-900 dark:text-white">Risk Management</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Server-enforced stake cap, max daily loss, max daily trades, consecutive loss pause, daily profit lock, and emergency stop.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={busy}
            onClick={() => onRequestEmergencyStop(!riskStatus?.emergencyStop)}
            className={`min-h-10 inline-flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold whitespace-nowrap transition-colors ${
              riskStatus?.emergencyStop
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                : 'bg-red-600 hover:bg-red-500 text-white'
            }`}
          >
            <AlertTriangle className="h-3.5 w-3.5" />
            {riskStatus?.emergencyStop ? 'Clear Emergency Stop' : 'Engage Emergency Stop'}
          </button>
          <button
            type="button"
            disabled={busy}
            onClick={onRequestResetDaily}
            className="min-h-10 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#0E1629] hover:bg-slate-50 dark:hover:bg-slate-800 px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap"
          >
            Reset Daily Counters
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className={`${glassCard} p-4`}>
          <p className="text-xs text-slate-500 dark:text-slate-400">Risk Guard Status</p>
          <p className={`mt-2 text-lg font-semibold ${riskStatus?.allowed ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
            {riskStatus?.allowed ? 'Clear' : 'Paused / Blocked'}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            {riskStatus?.reasons[0] || 'All risk thresholds nominal'}
          </p>
        </div>
        <div className={`${glassCard} p-4`}>
          <p className="text-xs text-slate-500 dark:text-slate-400">Daily Simulated Loss</p>
          <p className="mt-2 text-lg font-semibold font-mono tabular-nums text-slate-900 dark:text-white">
            ${riskStatus?.simulatedDailyLoss.toFixed(2)} / ${riskStatus?.limits.dailyLossLimit}
          </p>
          <p className="mt-1 text-xs text-slate-500">Auto-pauses on breach</p>
        </div>
        <div className={`${glassCard} p-4`}>
          <p className="text-xs text-slate-500 dark:text-slate-400">Daily Trades &amp; Profit</p>
          <p className="mt-2 text-lg font-semibold font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
            {riskStatus?.dailyTradesCount ?? 0} / {riskStatus?.limits.maxDailyTrades ?? 25}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Profit +${riskStatus?.simulatedDailyProfit.toFixed(2)} / ${riskStatus?.limits.dailyProfitTarget}
          </p>
        </div>
        <div className={`${glassCard} p-4`}>
          <p className="text-xs text-slate-500 dark:text-slate-400">Consecutive Losses</p>
          <p className="mt-2 text-lg font-semibold font-mono tabular-nums text-slate-900 dark:text-white">
            {riskStatus?.consecutiveLosses} / {riskStatus?.limits.maxConsecutiveLosses}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Open positions: {riskStatus?.activeTradesCount} / {riskStatus?.limits.maxSimultaneousTrades}
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className={`${glassCard} p-5 space-y-5`}>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">Maximum Stake Per Trade</label>
            <input
              type="number"
              min={1}
              max={100000}
              value={form.maxTradeAmount}
              onChange={(e) => setForm({ ...form, maxTradeAmount: Math.max(1, Number(e.target.value)) })}
              className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">Maximum Daily Loss</label>
            <input
              type="number"
              min={1}
              max={1000000}
              value={form.dailyLossLimit}
              onChange={(e) => setForm({ ...form, dailyLossLimit: Math.max(1, Number(e.target.value)) })}
              className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">Daily Profit Target</label>
            <input
              type="number"
              min={1}
              max={1000000}
              value={form.dailyProfitTarget}
              onChange={(e) => setForm({ ...form, dailyProfitTarget: Math.max(1, Number(e.target.value)) })}
              className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">Maximum Daily Trades</label>
            <input
              type="number"
              min={1}
              max={500}
              value={form.maxDailyTrades}
              onChange={(e) => setForm({ ...form, maxDailyTrades: Math.max(1, Number(e.target.value)) })}
              className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">Maximum Consecutive Losses</label>
            <input
              type="number"
              min={1}
              max={20}
              value={form.maxConsecutiveLosses}
              onChange={(e) => setForm({ ...form, maxConsecutiveLosses: Math.max(1, Number(e.target.value)) })}
              className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">Max Simultaneous Trades</label>
            <input
              type="number"
              min={1}
              max={20}
              value={form.maxSimultaneousTrades}
              onChange={(e) => setForm({ ...form, maxSimultaneousTrades: Math.max(1, Number(e.target.value)) })}
              className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
            />
          </div>
        </div>

        <div className="border-t border-slate-200 dark:border-slate-800 pt-4 space-y-3">
          <label className="inline-flex items-center gap-2 text-sm text-slate-800 dark:text-slate-200 cursor-pointer">
            <input
              type="checkbox"
              checked={form.tradingScheduleEnabled}
              onChange={(e) => setForm({ ...form, tradingScheduleEnabled: e.target.checked })}
              className="rounded border-slate-400 dark:border-slate-600"
            />
            Enforce UTC Trading Schedule Window
          </label>
          {form.tradingScheduleEnabled && (
            <div className="grid grid-cols-2 sm:w-80 gap-3">
              <div>
                <label className="block text-xs text-slate-500 dark:text-slate-400 mb-1">Start Hour (UTC)</label>
                <input
                  type="number"
                  min={0}
                  max={23}
                  value={form.tradingStartHourUtc}
                  onChange={(e) => setForm({ ...form, tradingStartHourUtc: Math.min(23, Math.max(0, Number(e.target.value))) })}
                  className="w-full min-h-10 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 dark:text-slate-400 mb-1">End Hour (UTC)</label>
                <input
                  type="number"
                  min={0}
                  max={23}
                  value={form.tradingEndHourUtc}
                  onChange={(e) => setForm({ ...form, tradingEndHourUtc: Math.min(23, Math.max(0, Number(e.target.value))) })}
                  className="w-full min-h-10 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
                />
              </div>
            </div>
          )}
        </div>

        {savedMsg && <p className="text-xs text-emerald-600 dark:text-emerald-400">{savedMsg}</p>}

        <button
          type="submit"
          disabled={busy}
          className="min-h-11 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-50 px-5 py-2.5 text-xs font-semibold text-white"
        >
          <ShieldCheck className="h-4 w-4" /> Save Risk Settings
        </button>
      </form>
    </div>
  );
}

export function SettingsView({
  aiSettings,
  assets,
  profile,
  activity,
  theme,
  busy,
  onToggleTheme,
  onSaveAiSettings,
  onUpdateProfile,
  onSignOut,
}: {
  aiSettings: AiSettings | null;
  assets: AssetDefinition[];
  profile: UserProfile;
  activity: ActivityEvent[];
  theme: 'dark' | 'light';
  busy: boolean;
  onToggleTheme: () => void;
  onSaveAiSettings: (settings: AiSettings) => Promise<void>;
  onUpdateProfile: (p: UserProfile) => void;
  onSignOut: () => void;
}) {
  const [aiForm, setAiForm] = useState<AiSettings | null>(aiSettings);
  const [profileForm, setProfileForm] = useState<UserProfile>(profile);
  const [aiSaved, setAiSaved] = useState(false);
  const [profileMsg, setProfileMsg] = useState<string | null>(null);
  const [profileErr, setProfileErr] = useState<string | null>(null);

  useEffect(() => {
    if (aiSettings) setAiForm(aiSettings);
  }, [aiSettings]);

  function toggleAsset(sym: string) {
    if (!aiForm) return;
    const exists = aiForm.enabledAssets.includes(sym);
    if (exists && aiForm.enabledAssets.length <= 1) return;
    setAiForm({
      ...aiForm,
      enabledAssets: exists ? aiForm.enabledAssets.filter((s) => s !== sym) : [...aiForm.enabledAssets, sym],
    });
  }

  async function handleSaveAi(e: FormEvent) {
    e.preventDefault();
    if (!aiForm) return;
    setAiSaved(false);
    await onSaveAiSettings(aiForm);
    setAiSaved(true);
  }

  async function handleSaveProfile(e: FormEvent) {
    e.preventDefault();
    setProfileMsg(null);
    setProfileErr(null);
    try {
      const updated = isSupabaseConfigured ? await updateSupabaseProfile(profileForm) : profileForm;
      onUpdateProfile(updated);
      setProfileMsg(isSupabaseConfigured ? 'Profile saved to Supabase.' : 'Profile updated in local research session.');
    } catch (error) {
      setProfileErr(error instanceof Error ? error.message : 'Profile update failed.');
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-900 dark:text-white">Platform Settings &amp; Profile</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Configure autonomous scan intervals, AI thresholds, theme preference, account identity, and audit log.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onToggleTheme}
            className="min-h-10 inline-flex items-center gap-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#0E1629] px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap"
          >
            {theme === 'dark' ? <Sun className="h-3.5 w-3.5 text-amber-400" /> : <Moon className="h-3.5 w-3.5 text-indigo-600" />}
            {theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          </button>
          <button
            type="button"
            onClick={onSignOut}
            className="min-h-10 inline-flex items-center gap-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#0E1629] hover:bg-slate-50 dark:hover:bg-slate-800 px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap"
          >
            <LogOut className="h-3.5 w-3.5" /> Sign Out
          </button>
        </div>
      </div>

      {/* AI Strategy & Scan Interval Settings */}
      {aiForm && (
        <form onSubmit={handleSaveAi} className={`${glassCard} p-5 space-y-5`}>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Quantitative AI &amp; Scheduler Configuration</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">Strategy Profile</label>
              <select
                value={aiForm.strategyProfile}
                onChange={(e) => setAiForm({ ...aiForm, strategyProfile: e.target.value as AiSettings['strategyProfile'] })}
                className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm text-slate-900 dark:text-white"
              >
                <option value="conservative">Conservative</option>
                <option value="balanced">Balanced</option>
                <option value="momentum">Momentum</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">Min Score (40–95)</label>
              <input
                type="number"
                min={40}
                max={95}
                value={aiForm.minSignalScore}
                onChange={(e) => setAiForm({ ...aiForm, minSignalScore: Math.min(95, Math.max(40, Number(e.target.value))) })}
                className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">Default Timeframe</label>
              <select
                value={aiForm.defaultTimeframe}
                onChange={(e) => setAiForm({ ...aiForm, defaultTimeframe: e.target.value as Timeframe })}
                className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm text-slate-900 dark:text-white"
              >
                <option value="1m">1 Minute</option>
                <option value="5m">5 Minutes</option>
                <option value="15m">15 Minutes</option>
                <option value="1h">1 Hour</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">Trade Expiry (sec)</label>
              <input
                type="number"
                min={60}
                max={3600}
                step={30}
                value={aiForm.expirySeconds}
                onChange={(e) => setAiForm({ ...aiForm, expirySeconds: Math.min(3600, Math.max(60, Number(e.target.value))) })}
                className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">Scan Interval (sec)</label>
              <input
                type="number"
                min={15}
                max={900}
                step={15}
                value={aiForm.scanIntervalSeconds}
                onChange={(e) => setAiForm({ ...aiForm, scanIntervalSeconds: Math.min(900, Math.max(15, Number(e.target.value))) })}
                className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-6 border-t border-slate-200 dark:border-slate-800 pt-4">
            <label className="inline-flex items-center gap-2 text-sm text-slate-800 dark:text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={aiForm.requireMtfAlignment}
                onChange={(e) => setAiForm({ ...aiForm, requireMtfAlignment: e.target.checked })}
              />
              Require Higher-Timeframe Alignment (MTF Filter)
            </label>
            <label className="inline-flex items-center gap-2 text-sm text-slate-800 dark:text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={aiForm.useGeminiCommentary}
                onChange={(e) => setAiForm({ ...aiForm, useGeminiCommentary: e.target.checked })}
              />
              Generate Gemini Analyst Commentary (explanations only)
            </label>
          </div>

          <div className="border-t border-slate-200 dark:border-slate-800 pt-4">
            <p className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">Autonomous Mode Watchlist</p>
            <div className="flex flex-wrap gap-2">
              {assets.map((asset) => {
                const active = aiForm.enabledAssets.includes(asset.symbol);
                return (
                  <button
                    key={asset.symbol}
                    type="button"
                    onClick={() => toggleAsset(asset.symbol)}
                    className={`min-h-9 inline-flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                      active
                        ? 'border-blue-500 bg-blue-500/15 text-blue-700 dark:text-blue-300'
                        : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#070B14] text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {active && <Check className="h-3 w-3" />}
                    {asset.symbol}
                  </button>
                );
              })}
            </div>
          </div>

          {aiSaved && <p className="text-xs text-emerald-600 dark:text-emerald-400">AI strategy configuration saved.</p>}

          <button
            type="submit"
            disabled={busy}
            className="min-h-11 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-50 px-5 py-2.5 text-xs font-semibold text-white"
          >
            Save AI &amp; Scheduler Settings
          </button>
        </form>
      )}

      {/* User Profile & Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <form onSubmit={handleSaveProfile} className={`${glassCard} p-5 space-y-4`}>
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Trader Profile</h3>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              {profile.authMode === 'supabase' ? 'Supabase Auth Active' : 'Local Research Session'}
            </span>
          </div>

          <div>
            <label className="block text-xs text-slate-500 dark:text-slate-400 mb-1">Email</label>
            <input
              type="email"
              disabled
              value={profileForm.email}
              className="w-full min-h-11 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-[#070B14] px-3 py-2 text-sm text-slate-500"
            />
          </div>

          <div>
            <label className="block text-xs text-slate-700 dark:text-slate-300 mb-1">Display Name</label>
            <input
              type="text"
              value={profileForm.displayName}
              onChange={(e) => setProfileForm({ ...profileForm, displayName: e.target.value })}
              className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm text-slate-900 dark:text-white"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-slate-700 dark:text-slate-300 mb-1">Preferred Currency</label>
              <select
                value={profileForm.preferredCurrency}
                onChange={(e) => setProfileForm({ ...profileForm, preferredCurrency: e.target.value })}
                className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm text-slate-900 dark:text-white"
              >
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="GBP">GBP (£)</option>
                <option value="NGN">NGN (₦)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-slate-700 dark:text-slate-300 mb-1">Timezone</label>
              <input
                type="text"
                value={profileForm.timezone}
                onChange={(e) => setProfileForm({ ...profileForm, timezone: e.target.value })}
                className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {profileMsg && <p className="text-xs text-emerald-600 dark:text-emerald-400">{profileMsg}</p>}
          {profileErr && <p className="text-xs text-red-600 dark:text-red-400">{profileErr}</p>}

          <button
            type="submit"
            className="min-h-11 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 px-4 py-2 text-xs font-semibold text-white"
          >
            Save Profile
          </button>
        </form>

        <div className={`${glassCard} p-5`}>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3">Recent Account Activity</h3>
          {activity.length === 0 ? (
            <p className="text-xs text-slate-500 dark:text-slate-400">No activity recorded yet.</p>
          ) : (
            <div className="space-y-2.5 max-h-[340px] overflow-y-auto pr-1">
              {activity.slice(0, 25).map((ev) => (
                <div key={ev.id} className="border-b border-slate-200 dark:border-slate-800/80 pb-2 text-xs">
                  <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
                    <span className="font-medium text-slate-800 dark:text-slate-300">
                      {ev.category} · {ev.eventType}
                    </span>
                    <span className="font-mono tabular-nums">{new Date(ev.createdAt).toLocaleTimeString()}</span>
                  </div>
                  <p className="mt-0.5 text-slate-600 dark:text-slate-400">{ev.summary}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
