export type Timeframe = '1m' | '5m' | '15m' | '1h';
export type OperatingMode = 'signals' | 'assisted' | 'automatic';
export type StrategyProfile = 'conservative' | 'balanced' | 'momentum';

export type NavSection =
  | 'overview'
  | 'scanner'
  | 'live-markets'
  | 'signals'
  | 'paper-trading'
  | 'history'
  | 'analytics'
  | 'risk'
  | 'brokers'
  | 'settings';

export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface AssetDefinition {
  symbol: string;
  name: string;
  category: 'FX' | 'CRYPTO' | 'COMMODITY';
  instrumentType: 'FOREX' | 'CRYPTO' | 'COMMODITY';
  decimals: number;
  binaryOptionsOfferedByBroker?: boolean;
}

export interface IndicatorSnapshot {
  ema9: number;
  ema21: number;
  ema50: number;
  ema200: number | null;
  rsi14: number;
  macdLine: number;
  macdSignal: number;
  macdHistogram: number;
  bbUpper: number;
  bbMiddle: number;
  bbLower: number;
  bbBandwidthPct: number;
  bbPercentB: number;
  atr14: number;
  atrPct: number;
  nearestSupport: number;
  nearestResistance: number;
  supportDistancePct: number;
  resistanceDistancePct: number;
  trend: 'UPTREND' | 'DOWNTREND' | 'RANGING';
  volatilityRegime: 'LOW' | 'NORMAL' | 'HIGH' | 'EXTREME';
  patterns: string[];
  priceActionSummary: string;
}

export interface MultiTimeframeSummary {
  primaryTimeframe: Timeframe;
  higherTimeframe: Timeframe;
  higherTrend: 'UPTREND' | 'DOWNTREND' | 'RANGING' | 'UNAVAILABLE';
  higherRsi: number | null;
  alignment: 'ALIGNED_BULLISH' | 'ALIGNED_BEARISH' | 'CONFLICT' | 'NEUTRAL';
}

export interface BacktestSampleStats {
  sampleSize: number;
  wins: number;
  losses: number;
  winRatePct: number | null;
  expectancyPerUnit: number | null;
  horizonBars: number;
  note: string;
}

export interface RiskAssessment {
  level: 'LOW' | 'MODERATE' | 'HIGH' | 'EXTREME';
  volatilityRegime: 'LOW' | 'NORMAL' | 'HIGH' | 'EXTREME' | 'UNKNOWN';
  atrPct: number | null;
  suggestedStakePct: number;
  summary: string;
}

export interface SupportingIndicatorsSummary {
  emaAlignment: string;
  rsiState: string;
  macdState: string;
  bollingerState: string;
  supportResistanceState: string;
  candlestickPattern: string;
  trendDirection: string;
  volatilityState: string;
  multiTimeframe: string;
}

export interface GeminiCommentary {
  available: boolean;
  model: string;
  summary: string | null;
  riskNote: string | null;
  error?: string;
}

export interface SignalRecord {
  id: string;
  symbol: string;
  timeframe: Timeframe;
  direction: 'CALL' | 'PUT' | 'WAIT';
  score: number;
  confidenceScore: number;
  bullishScore: number;
  bearishScore: number;
  entryPrice: number | null;
  suggestedExpirySeconds: number;
  provider: string;
  marketStatus?: 'OPEN' | 'DELAYED_OR_CLOSED' | 'UNAVAILABLE';
  isStale?: boolean;
  timestamp: string;
  indicators: IndicatorSnapshot | null;
  supportingIndicators: SupportingIndicatorsSummary | null;
  riskAssessment: RiskAssessment | null;
  mtf: MultiTimeframeSummary | null;
  backtest: BacktestSampleStats;
  reasons: string[];
  warning: string;
  aiExplanation: GeminiCommentary | null;
}

export interface CandleFeedResponse {
  ok: boolean;
  symbol: string;
  instrumentType: 'FOREX' | 'CRYPTO' | 'COMMODITY';
  timeframe: Timeframe;
  candles: Candle[];
  currentPrice: number | null;
  priceChangePct: number | null;
  provider: string;
  marketStatus: 'OPEN' | 'DELAYED_OR_CLOSED' | 'UNAVAILABLE';
  fetchedAt: string;
  lastBarAt: string | null;
  latencyMs: number;
  isStale: boolean;
  error?: string;
  overlays?: {
    ema9: number[];
    ema21: number[];
    ema50: number[];
    bbUpper: number;
    bbMiddle: number;
    bbLower: number;
  };
}

export interface ScannerRow {
  symbol: string;
  name: string;
  category: string;
  instrumentType: 'FOREX' | 'CRYPTO' | 'COMMODITY';
  timeframe: Timeframe;
  direction: 'CALL' | 'PUT' | 'WAIT';
  score: number;
  suggestedExpirySeconds: number;
  entryPrice: number | null;
  provider: string;
  marketStatus?: 'OPEN' | 'DELAYED_OR_CLOSED' | 'UNAVAILABLE';
  isStale?: boolean;
  trend: string;
  rsi14: number | null;
  volatility: string;
  mtfAlignment: string;
  backtestWinRate: number | null;
  backtestSampleSize: number;
  riskLevel: 'LOW' | 'MODERATE' | 'HIGH' | 'EXTREME';
  reasons: string[];
  error: string | null;
  timestamp: string;
}

export interface PaperTrade {
  id: string;
  symbol: string;
  timeframe: Timeframe;
  direction: 'CALL' | 'PUT';
  mode: OperatingMode | 'manual';
  amount: number;
  payoutRate: number;
  entryPrice: number | null;
  exitPrice: number | null;
  expirySeconds: number;
  expiresAt: string | null;
  status: string;
  pnl: number | null;
  signalScore: number | null;
  provider: string;
  settledBy: string | null;
  createdAt: string;
  closedAt: string | null;
}

export interface AssistedProposal {
  id: string;
  symbol: string;
  timeframe: Timeframe;
  direction: 'CALL' | 'PUT';
  score: number;
  recommendedAmount: number;
  entryPrice: number | null;
  expirySeconds: number;
  reasons: string[];
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED';
  createdAt: string;
  decidedAt: string | null;
}

export interface RiskSettings {
  maxTradeAmount: number;
  dailyLossLimit: number;
  dailyProfitTarget: number;
  maxConsecutiveLosses: number;
  maxDailyTrades: number;
  maxSimultaneousTrades: number;
  tradingScheduleEnabled: boolean;
  tradingStartHourUtc: number;
  tradingEndHourUtc: number;
  emergencyStop: boolean;
}

export interface RiskStatus {
  allowed: boolean;
  reasons: string[];
  simulatedDailyLoss: number;
  simulatedDailyProfit: number;
  netDailyPnl: number;
  dailyTradesCount: number;
  consecutiveLosses: number;
  activeTradesCount: number;
  scheduleOpen: boolean;
  emergencyStop: boolean;
  autoPausedReason: string | null;
  limits: RiskSettings;
}

export interface AiSettings {
  strategyProfile: StrategyProfile;
  minSignalScore: number;
  requireMtfAlignment: boolean;
  enabledAssets: string[];
  defaultTimeframe: Timeframe;
  expirySeconds: number;
  scanIntervalSeconds: number;
  useGeminiCommentary: boolean;
}

export interface BrokerConnectorDiagnostics {
  configured: boolean;
  urlValid: boolean;
  hadVarNamePrefix: boolean;
  isLocalhost: boolean;
  reachable: boolean;
  authenticated: boolean;
  credentialsConfigured: boolean | null;
  tokenConfigured: boolean;
  latencyMs: number | null;
  targetHost: string | null;
  warnings: string[];
  lastConnectorError: string | null;
}

export interface BrokerStatusSnapshot {
  broker: string;
  adapterInstalled: boolean;
  authorisedApiVerified: boolean;
  connectorConfigured: boolean;
  demoSupported: boolean;
  realAccountSupported: boolean;
  orderExecutionSupported: boolean;
  historySupported: boolean;
  environment: 'demo' | 'real' | null;
  message: string;
  connected: boolean;
  executionEnabled: boolean;
  accountType: string | null;
  balance: number | null;
  currency: string | null;
  connectorUrlConfigured: boolean;
  lastCheckedAt: string;
  limitations: string[];
  diagnostics?: BrokerConnectorDiagnostics;
}

export interface BrokerCatalogItem {
  id: string;
  name: string;
  status: 'INTEGRATED_READONLY' | 'PLANNED';
  description: string;
  realExecutionEnabled: boolean;
}

export interface PeriodPerformanceRow {
  period: string;
  trades: number;
  wins: number;
  losses: number;
  netPnl: number;
  winRatePct: number | null;
}

export interface AnalyticsSummary {
  startingVirtualBalance: number;
  currentVirtualBalance: number;
  todayPnl: number;
  todayTrades: number;
  totalTrades: number;
  activeTrades: number;
  wins: number;
  losses: number;
  winRatePct: number | null;
  grossProfit: number;
  grossLoss: number;
  netPnl: number;
  profitFactor: number | null;
  maxDrawdown: number;
  equityCurve: Array<{ index: number; timestamp: string; symbol: string; equity: number; pnl: number }>;
  dailyStats: PeriodPerformanceRow[];
  weeklyStats: PeriodPerformanceRow[];
  monthlyStats: PeriodPerformanceRow[];
  bySymbol: Array<{ symbol: string; trades: number; wins: number; losses: number; netPnl: number }>;
}

export interface ActivityEvent {
  id: string;
  category: string;
  eventType: string;
  summary: string;
  createdAt: string;
}

export interface HealthStatus {
  status: string;
  mode: OperatingMode;
  executionMode: string;
  liveExecution: boolean;
  version: string;
  virtualBalance?: {
    startingBalance: number;
    currentBalance: number;
    totalNetPnl: number;
  };
  scheduler: {
    armed: boolean;
    scanIntervalSeconds: number;
    lastScanAt: string | null;
    lastCycleSummary: string | null;
  };
  supabase: {
    clientConfigured: boolean;
    serverConfigured: boolean;
  };
  geminiConfigured: boolean;
  iqConnectorConfigured: boolean;
  iqConnectorUrlValid?: boolean;
}

export interface UserProfile {
  id: string;
  email: string;
  displayName: string;
  role: string;
  preferredCurrency: string;
  timezone: string;
  authMode: 'supabase' | 'local-preview';
}

export interface ToastNotice {
  id: string;
  kind: 'info' | 'success' | 'error' | 'warning';
  title: string;
  message: string;
  createdAt: string;
}
