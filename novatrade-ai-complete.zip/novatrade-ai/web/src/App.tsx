import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Activity,
  BarChart3,
  Bell,
  Bot,
  Cable,
  CandlestickChart as CandleIcon,
  CheckCircle2,
  ChevronDown,
  History,
  LayoutDashboard,
  LogOut,
  Menu,
  Moon,
  MoreHorizontal,
  Play,
  Radar,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  Sliders,
  Sun,
  User,
  Wallet,
  X,
  XCircle,
} from 'lucide-react';
import type {
  ActivityEvent,
  AiSettings,
  AnalyticsSummary,
  AssetDefinition,
  AssistedProposal,
  BrokerCatalogItem,
  BrokerStatusSnapshot,
  CandleFeedResponse,
  HealthStatus,
  NavSection,
  OperatingMode,
  PaperTrade,
  RiskSettings,
  RiskStatus,
  ScannerRow,
  SignalRecord,
  Timeframe,
  ToastNotice,
  UserProfile,
} from './types';
import { apiRequest } from './lib/api';
import {
  fetchUserWorkspaceFromSupabase,
  isAuthCallbackRoute,
  isSupabaseConfigured,
  loadSupabaseProfile,
  persistPaperTradeToSupabase,
  persistSignalToSupabase,
  signOutSupabase,
  supabase,
  syncSupabaseSettings,
} from './lib/supabase';
import { CandlestickChart } from './components/CandlestickChart';
import { EquityChart } from './components/EquityChart';
import { AuthGateView } from './components/AuthGateView';
import { AuthCallbackView } from './components/AuthCallbackView';
import { ConfirmDialog } from './components/ConfirmDialog';
import {
  AnalyticsView,
  MarketScannerView,
  PaperTradingDeskView,
  SignalsView,
  TradeHistoryView,
} from './components/TradingViews';
import {
  BrokerConnectionsView,
  RiskManagementView,
  SettingsView,
} from './components/BrokerAndRiskViews';

const LOCAL_PROFILE_KEY = 'novatrade_local_profile_v1';
const THEME_STORAGE_KEY = 'novatrade_theme_v1';

const NAV_ITEMS: Array<{ id: NavSection; label: string; icon: typeof LayoutDashboard }> = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'scanner', label: 'AI Scanner', icon: Radar },
  { id: 'live-markets', label: 'Live Markets', icon: CandleIcon },
  { id: 'signals', label: 'Trading Signals', icon: Activity },
  { id: 'paper-trading', label: 'Paper Trading', icon: Wallet },
  { id: 'history', label: 'Trade History', icon: History },
  { id: 'analytics', label: 'Performance Analytics', icon: BarChart3 },
  { id: 'risk', label: 'Risk Management', icon: ShieldCheck },
  { id: 'brokers', label: 'Broker Connections', icon: Cable },
  { id: 'settings', label: 'Settings', icon: Sliders },
];

const GLASS_CARD =
  'rounded-2xl border border-slate-200 dark:border-indigo-500/20 bg-white/95 dark:bg-[#0E1629]/85 backdrop-blur-md shadow-sm';

export default function App() {
  const [inAuthCallback, setInAuthCallback] = useState(() => isAuthCallbackRoute());
  const [authReady, setAuthReady] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [supabaseAccessToken, setSupabaseAccessToken] = useState<string | null>(null);
  const [activeNav, setActiveNav] = useState<NavSection>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileMoreOpen, setMobileMoreOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const [lastSeenActivityCount, setLastSeenActivityCount] = useState(0);

  // Light / Dark theme
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    try {
      const saved = localStorage.getItem(THEME_STORAGE_KEY);
      return saved === 'light' ? 'light' : 'dark';
    } catch {
      return 'dark';
    }
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') root.classList.add('dark');
    else root.classList.remove('dark');
    try {
      localStorage.setItem(THEME_STORAGE_KEY, theme);
    } catch {
      // Ignore storage errors
    }
  }, [theme]);

  // Market & Chart state
  const [assets, setAssets] = useState<AssetDefinition[]>([]);
  const [selectedSymbol, setSelectedSymbol] = useState('EURUSD');
  const [selectedTimeframe, setSelectedTimeframe] = useState<Timeframe>('1m');
  const [candleFeed, setCandleFeed] = useState<CandleFeedResponse | null>(null);
  const [candleLoading, setCandleLoading] = useState(false);
  const [candleError, setCandleError] = useState<string | null>(null);

  // Platform state
  const [health, setHealth] = useState<HealthStatus | null>(null);
  const [mode, setMode] = useState<OperatingMode>('signals');
  const [autoArmed, setAutoArmed] = useState(false);
  const [riskStatus, setRiskStatus] = useState<RiskStatus | null>(null);
  const [aiSettings, setAiSettings] = useState<AiSettings | null>(null);
  const [brokerStatus, setBrokerStatus] = useState<BrokerStatusSnapshot | null>(null);
  const [brokerCatalog, setBrokerCatalog] = useState<BrokerCatalogItem[]>([]);

  // Signals, Trades, Proposals, Analytics, Activity
  const [currentAnalysis, setCurrentAnalysis] = useState<SignalRecord | null>(null);
  const [signals, setSignals] = useState<SignalRecord[]>([]);
  const [scannerRows, setScannerRows] = useState<ScannerRow[]>([]);
  const [scanProgress, setScanProgress] = useState<{
    active: boolean;
    completed: number;
    total: number;
    currentSymbol: string | null;
    latestDirection: 'CALL' | 'PUT' | 'WAIT' | null;
  }>({ active: false, completed: 0, total: 0, currentSymbol: null, latestDirection: null });
  const [paperTrades, setPaperTrades] = useState<PaperTrade[]>([]);
  const [activeTrades, setActiveTrades] = useState<PaperTrade[]>([]);
  const [proposals, setProposals] = useState<AssistedProposal[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsSummary | null>(null);
  const [activity, setActivity] = useState<ActivityEvent[]>([]);

  // Interactive controls, toasts, and confirmations
  const [manualStake, setManualStake] = useState(50);
  const [busy, setBusy] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [toasts, setToasts] = useState<ToastNotice[]>([]);
  const [confirmState, setConfirmState] = useState<{
    type: 'emergency-stop' | 'reset-daily' | 'arm-auto' | null;
    payload?: boolean;
  }>({ type: null });

  const pushToast = useCallback((kind: ToastNotice['kind'], title: string, message: string) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    setToasts((prev) => [{ id, kind, title, message, createdAt: new Date().toISOString() }, ...prev].slice(0, 4));
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 5200);
  }, []);

  const authHeaders = useMemo<Record<string, string>>(() => {
    const headers: Record<string, string> = {};
    if (supabaseAccessToken) {
      headers.Authorization = `Bearer ${supabaseAccessToken}`;
    }
    return headers;
  }, [supabaseAccessToken]);

  // Auth & persistent session initialization
  useEffect(() => {
    if (!isSupabaseConfigured || !supabase) {
      try {
        const saved = localStorage.getItem(LOCAL_PROFILE_KEY);
        if (saved) {
          setProfile(JSON.parse(saved) as UserProfile);
        } else {
          setProfile({
            id: 'local-research-session',
            email: 'research@novatrade.local',
            displayName: 'Research Workspace',
            role: 'trader',
            preferredCurrency: 'USD',
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
            authMode: 'local-preview',
          });
        }
      } catch {
        setProfile(null);
      }
      setAuthReady(true);
      return;
    }

    let mounted = true;
    supabase.auth.getSession().then(async ({ data }) => {
      if (!mounted) return;
      if (data.session?.user) {
        setSupabaseAccessToken(data.session.access_token);
        const p = await loadSupabaseProfile(data.session.user.id, data.session.user.email || '');
        if (mounted) setProfile(p);
      } else {
        setProfile(null);
      }
      setAuthReady(true);
    });

    const { data: sub } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (!mounted) return;
      if (session?.user) {
        setSupabaseAccessToken(session.access_token);
        const p = await loadSupabaseProfile(session.user.id, session.user.email || '');
        if (mounted) setProfile(p);
      } else {
        setSupabaseAccessToken(null);
        setProfile(null);
      }
    });

    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const refreshPlatformState = useCallback(async () => {
    try {
      const [
        healthRes,
        assetsRes,
        riskRes,
        aiRes,
        autoRes,
        brokerRes,
        catalogRes,
        tradesRes,
        signalsRes,
        proposalsRes,
        analyticsRes,
        activityRes,
      ] = await Promise.all([
        apiRequest<HealthStatus>('/api/health', { headers: authHeaders }),
        apiRequest<{ assets: AssetDefinition[] }>('/api/market/assets', { headers: authHeaders }),
        apiRequest<RiskStatus>('/api/risk/status', { headers: authHeaders }),
        apiRequest<{ settings: AiSettings }>('/api/ai/settings', { headers: authHeaders }),
        apiRequest<{ armed: boolean }>('/api/auto-paper/status', { headers: authHeaders }),
        apiRequest<BrokerStatusSnapshot>('/api/broker/status', { headers: authHeaders }),
        apiRequest<{ brokers: BrokerCatalogItem[] }>('/api/broker/catalog', { headers: authHeaders }),
        apiRequest<{ trades: PaperTrade[]; activeTrades: PaperTrade[] }>('/api/paper-trades', { headers: authHeaders }),
        apiRequest<{ signals: SignalRecord[] }>('/api/signals', { headers: authHeaders }),
        apiRequest<{ proposals: AssistedProposal[] }>('/api/assisted/proposals', { headers: authHeaders }),
        apiRequest<AnalyticsSummary>('/api/analytics', { headers: authHeaders }),
        apiRequest<{ events: ActivityEvent[] }>('/api/activity', { headers: authHeaders }),
      ]);

      setHealth(healthRes);
      setMode(healthRes.mode);
      setAssets(assetsRes.assets);
      setRiskStatus(riskRes);
      setAiSettings(aiRes.settings);
      setAutoArmed(autoRes.armed);
      setBrokerStatus(brokerRes);
      setBrokerCatalog(catalogRes.brokers);
      setPaperTrades(tradesRes.trades);
      setActiveTrades(tradesRes.activeTrades);
      setSignals(signalsRes.signals);
      setProposals(proposalsRes.proposals);
      setAnalytics(analyticsRes);
      setActivity(activityRes.events);
      if (!currentAnalysis && signalsRes.signals[0]) {
        setCurrentAnalysis(signalsRes.signals[0]);
      }
    } catch (err) {
      pushToast('error', 'Connection Issue', err instanceof Error ? err.message : 'Unable to reach NovaTrade API.');
    }
  }, [authHeaders, currentAnalysis, pushToast]);

  // Hydrate Supabase user workspace once session becomes active
  useEffect(() => {
    if (!profile || profile.authMode !== 'supabase' || !supabaseAccessToken) return;
    let active = true;
    fetchUserWorkspaceFromSupabase(profile.id).then(async (workspace) => {
      if (!active || !workspace) return;
      try {
        await apiRequest('/api/state/hydrate', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify(workspace),
        });
        await refreshPlatformState();
      } catch {
        // Non-fatal
      }
    });
    return () => {
      active = false;
    };
  }, [profile, supabaseAccessToken, authHeaders, refreshPlatformState]);

  const loadCandles = useCallback(async (symbol: string, timeframe: Timeframe) => {
    setCandleLoading(true);
    setCandleError(null);
    try {
      const res = await apiRequest<CandleFeedResponse>(
        `/api/market/candles?symbol=${encodeURIComponent(symbol)}&timeframe=${timeframe}&limit=140`
      );
      setCandleFeed(res);
    } catch (err) {
      setCandleError(err instanceof Error ? err.message : 'Failed to load candles.');
      setCandleFeed(null);
    } finally {
      setCandleLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!profile) return;
    void refreshPlatformState();
    const timer = setInterval(() => {
      void refreshPlatformState();
    }, 10_000);
    return () => clearInterval(timer);
  }, [profile, refreshPlatformState]);

  // Live price & candle refresh loop on Live Markets
  useEffect(() => {
    if (!profile) return;
    void loadCandles(selectedSymbol, selectedTimeframe);
    const liveFeedTimer = setInterval(() => {
      if (activeNav === 'live-markets' || activeNav === 'overview') {
        void loadCandles(selectedSymbol, selectedTimeframe);
      }
    }, 12_000);
    return () => clearInterval(liveFeedTimer);
  }, [profile, selectedSymbol, selectedTimeframe, activeNav, loadCandles]);

  const selectedAssetMeta = useMemo(
    () =>
      assets.find((a) => a.symbol === selectedSymbol) || {
        symbol: selectedSymbol,
        name: selectedSymbol,
        category: 'FX' as const,
        instrumentType: 'FOREX' as const,
        decimals: 5,
      },
    [assets, selectedSymbol]
  );

  const groupedAssets = useMemo(() => {
    const list = assets.length > 0 ? assets : [selectedAssetMeta];
    return {
      FOREX: list.filter((a) => a.instrumentType === 'FOREX'),
      CRYPTO: list.filter((a) => a.instrumentType === 'CRYPTO'),
      COMMODITY: list.filter((a) => a.instrumentType === 'COMMODITY'),
    };
  }, [assets, selectedAssetMeta]);

  async function handleRunAnalysis() {
    setBusy(true);
    try {
      const res = await apiRequest<{ signal: SignalRecord; marketError?: string }>('/api/signals/analyse', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ symbol: selectedSymbol, timeframe: selectedTimeframe }),
      });
      setCurrentAnalysis(res.signal);
      if (profile?.authMode === 'supabase') {
        void persistSignalToSupabase(profile.id, res.signal).catch(() => undefined);
      }
      if (res.marketError) {
        pushToast('error', 'Market Feed Unavailable', res.marketError);
      } else {
        pushToast(
          res.signal.direction === 'WAIT' ? 'info' : 'success',
          `${res.signal.symbol} (${res.signal.timeframe}) · ${res.signal.direction}`,
          `Confidence ${res.signal.confidenceScore ?? res.signal.score}/100 · Risk ${res.signal.riskAssessment?.level || 'MODERATE'}`
        );
      }
      await refreshPlatformState();
      await loadCandles(selectedSymbol, selectedTimeframe);
    } catch (err) {
      pushToast('error', 'Analysis Failed', err instanceof Error ? err.message : 'Quantitative evaluation failed.');
    } finally {
      setBusy(false);
    }
  }

  async function handleModeChange(nextMode: OperatingMode) {
    setBusy(true);
    try {
      await apiRequest('/api/mode', {
        method: 'PUT',
        headers: authHeaders,
        body: JSON.stringify({ mode: nextMode }),
      });
      setMode(nextMode);
      if (profile && isSupabaseConfigured && aiSettings && riskStatus) {
        void syncSupabaseSettings(
          profile.id,
          nextMode,
          riskStatus.limits,
          aiSettings,
          autoArmed,
          analytics?.startingVirtualBalance
        ).catch(() => undefined);
      }
      pushToast('info', 'Operating Mode Updated', `Switched to ${nextMode.toUpperCase()} mode.`);
      await refreshPlatformState();
    } catch (err) {
      pushToast('error', 'Mode Switch Failed', err instanceof Error ? err.message : 'Could not change mode.');
    } finally {
      setBusy(false);
    }
  }

  async function handleCreateAssistedProposal() {
    setBusy(true);
    try {
      const res = await apiRequest<{ analysis: SignalRecord; proposal: AssistedProposal | null; notice: string }>(
        '/api/assisted/propose',
        {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify({ symbol: selectedSymbol, timeframe: selectedTimeframe }),
        }
      );
      setCurrentAnalysis(res.analysis);
      pushToast(res.proposal ? 'warning' : 'info', 'Assisted Proposal', res.notice);
      await refreshPlatformState();
    } catch (err) {
      pushToast('error', 'Assisted Analysis Failed', err instanceof Error ? err.message : 'Request failed.');
    } finally {
      setBusy(false);
    }
  }

  async function handleApproveProposal(id: string) {
    setBusy(true);
    try {
      const res = await apiRequest<{ trade?: PaperTrade; notice: string }>(`/api/assisted/proposals/${id}/approve`, {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({}),
      });
      if (res.trade && profile?.authMode === 'supabase') {
        void persistPaperTradeToSupabase(profile.id, res.trade).catch(() => undefined);
      }
      pushToast('success', 'Paper Trade Approved', res.notice);
      await refreshPlatformState();
    } catch (err) {
      pushToast('error', 'Approval Rejected', err instanceof Error ? err.message : 'Blocked by risk guard.');
    } finally {
      setBusy(false);
    }
  }

  async function handleRejectProposal(id: string) {
    setBusy(true);
    try {
      await apiRequest(`/api/assisted/proposals/${id}/reject`, {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({}),
      });
      pushToast('info', 'Proposal Rejected', 'No paper position opened.');
      await refreshPlatformState();
    } finally {
      setBusy(false);
    }
  }

  async function executeToggleAutoArm(targetArmed: boolean) {
    setBusy(true);
    try {
      const res = await apiRequest<{ armed: boolean; notice: string }>('/api/auto-paper/arm', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ enabled: targetArmed }),
      });
      setAutoArmed(res.armed);
      if (res.armed) setMode('automatic');
      if (profile && isSupabaseConfigured && aiSettings && riskStatus) {
        await syncSupabaseSettings(
          profile.id,
          res.armed ? 'automatic' : mode,
          riskStatus.limits,
          aiSettings,
          res.armed,
          analytics?.startingVirtualBalance
        ).catch(() => undefined);
      }
      pushToast(res.armed ? 'success' : 'info', res.armed ? 'Autonomous Mode Armed' : 'Autonomous Mode Paused', res.notice);
      await refreshPlatformState();
    } catch (err) {
      pushToast('error', 'Autonomous Mode Blocked', err instanceof Error ? err.message : 'Risk guard blocked automatic mode.');
    } finally {
      setBusy(false);
    }
  }

  async function handleRunAutoCycleNow() {
    setBusy(true);
    try {
      const res = await apiRequest<{ summary: string }>('/api/auto-paper/cycle', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({}),
      });
      pushToast('info', 'Scheduler Cycle Complete', res.summary);
      await refreshPlatformState();
    } catch (err) {
      pushToast('error', 'Scheduler Cycle Failed', err instanceof Error ? err.message : 'Cycle error.');
    } finally {
      setBusy(false);
    }
  }

  async function handleOpenManualPaperTrade(symbol: string, direction: 'CALL' | 'PUT', amount: number) {
    setBusy(true);
    try {
      const res = await apiRequest<{ trade: PaperTrade; notice: string }>('/api/paper-trades', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({
          symbol,
          timeframe: selectedTimeframe,
          direction,
          amount,
          entryPrice: symbol === selectedSymbol ? candleFeed?.currentPrice ?? null : null,
          expirySeconds: aiSettings?.expirySeconds ?? 180,
          mode,
        }),
      });
      if (res.trade && profile?.authMode === 'supabase') {
        void persistPaperTradeToSupabase(profile.id, res.trade).catch(() => undefined);
      }
      pushToast('success', `Paper ${direction} Opened`, `${symbol} · $${amount.toFixed(2)} (${res.notice})`);
      await refreshPlatformState();
    } catch (err) {
      pushToast('error', 'Paper Trade Blocked', err instanceof Error ? err.message : 'Risk limits exceeded.');
    } finally {
      setBusy(false);
    }
  }

  async function handleSettleTrade(id: string, outcome: 'win' | 'loss') {
    setBusy(true);
    try {
      const res = await apiRequest<{ trade: PaperTrade }>(`/api/paper-trades/${id}/settle`, {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ outcome }),
      });
      if (res.trade && profile?.authMode === 'supabase') {
        void persistPaperTradeToSupabase(profile.id, res.trade).catch(() => undefined);
      }
      pushToast(outcome === 'win' ? 'success' : 'warning', `Trade Settled (${outcome.toUpperCase()})`, `${res.trade.symbol} PnL ${res.trade.pnl ?? 0}`);
      await refreshPlatformState();
    } catch (err) {
      pushToast('error', 'Settlement Failed', err instanceof Error ? err.message : 'Unable to settle.');
    } finally {
      setBusy(false);
    }
  }

  async function handleCancelTrade(id: string) {
    setBusy(true);
    try {
      const res = await apiRequest<{ trade: PaperTrade }>(`/api/paper-trades/${id}/cancel`, {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({}),
      });
      if (res.trade && profile?.authMode === 'supabase') {
        void persistPaperTradeToSupabase(profile.id, res.trade).catch(() => undefined);
      }
      pushToast('info', 'Paper Trade Cancelled', 'Position cancelled without PnL.');
      await refreshPlatformState();
    } finally {
      setBusy(false);
    }
  }

  async function handleUpdateStartingBalance(startingVirtualBalance: number) {
    setBusy(true);
    try {
      await apiRequest('/api/virtual-balance', {
        method: 'PUT',
        headers: authHeaders,
        body: JSON.stringify({ startingVirtualBalance }),
      });
      if (profile && isSupabaseConfigured && aiSettings && riskStatus) {
        await syncSupabaseSettings(profile.id, mode, riskStatus.limits, aiSettings, autoArmed, startingVirtualBalance);
      }
      pushToast('success', 'Virtual Balance Updated', `Starting balance set to $${startingVirtualBalance.toLocaleString()}.`);
      await refreshPlatformState();
    } finally {
      setBusy(false);
    }
  }

  async function handleProgressiveScan(symbols: string[]) {
    if (symbols.length === 0) return;
    setScanning(true);
    setScanProgress({
      active: true,
      completed: 0,
      total: symbols.length,
      currentSymbol: symbols[0],
      latestDirection: null,
    });
    const collected: ScannerRow[] = [];

    try {
      for (let i = 0; i < symbols.length; i++) {
        const sym = symbols[i];
        setScanProgress((prev) => ({ ...prev, currentSymbol: sym }));
        const res = await apiRequest<{ row: ScannerRow }>('/api/scanner/scan-one', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify({ symbol: sym, timeframe: selectedTimeframe }),
        });
        collected.push(res.row);
        setScannerRows([...collected]);
        setScanProgress({
          active: i + 1 < symbols.length,
          completed: i + 1,
          total: symbols.length,
          currentSymbol: sym,
          latestDirection: res.row.direction,
        });
      }
      pushToast('success', 'AI Market Scan Complete', `Evaluated ${collected.length} instruments on ${selectedTimeframe}.`);
      await refreshPlatformState();
    } catch (err) {
      pushToast('error', 'Market Scan Interrupted', err instanceof Error ? err.message : 'Scan error.');
    } finally {
      setScanning(false);
    }
  }

  async function handleSaveRisk(settings: RiskSettings) {
    setBusy(true);
    try {
      await apiRequest('/api/risk/settings', {
        method: 'PUT',
        headers: authHeaders,
        body: JSON.stringify(settings),
      });
      if (profile && isSupabaseConfigured && aiSettings) {
        await syncSupabaseSettings(
          profile.id,
          mode,
          settings,
          aiSettings,
          autoArmed,
          analytics?.startingVirtualBalance
        );
      }
      pushToast('success', 'Risk Limits Saved', 'Capital protection thresholds enforced server-side.');
      await refreshPlatformState();
    } finally {
      setBusy(false);
    }
  }

  async function executeEmergencyStop(engaged: boolean) {
    setBusy(true);
    try {
      await apiRequest('/api/risk/emergency-stop', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ engaged }),
      });
      if (profile && isSupabaseConfigured && aiSettings && riskStatus) {
        void syncSupabaseSettings(
          profile.id,
          mode,
          { ...riskStatus.limits, emergencyStop: engaged },
          aiSettings,
          engaged ? false : autoArmed,
          analytics?.startingVirtualBalance
        ).catch(() => undefined);
      }
      pushToast(
        engaged ? 'error' : 'success',
        engaged ? 'Emergency Stop Engaged' : 'Emergency Stop Cleared',
        engaged ? 'All automatic paper execution has been halted.' : 'Risk guard restored to normal checks.'
      );
      await refreshPlatformState();
    } finally {
      setBusy(false);
    }
  }

  async function executeResetDailyRisk() {
    setBusy(true);
    try {
      await apiRequest('/api/risk/reset-daily', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({}),
      });
      pushToast('info', 'Daily Counters Reset', 'Simulated daily loss, profit, trade count, and loss streak cleared.');
      await refreshPlatformState();
    } finally {
      setBusy(false);
    }
  }

  async function handleSaveAiSettings(settings: AiSettings) {
    setBusy(true);
    try {
      await apiRequest('/api/ai/settings', {
        method: 'PUT',
        headers: authHeaders,
        body: JSON.stringify(settings),
      });
      if (profile && isSupabaseConfigured && riskStatus) {
        await syncSupabaseSettings(
          profile.id,
          mode,
          riskStatus.limits,
          settings,
          autoArmed,
          analytics?.startingVirtualBalance
        );
      }
      pushToast('success', 'AI Settings Saved', `Scan interval ${settings.scanIntervalSeconds}s · Min score ${settings.minSignalScore}`);
      await refreshPlatformState();
    } finally {
      setBusy(false);
    }
  }

  async function handleSignOut() {
    if (isSupabaseConfigured) {
      await signOutSupabase();
    } else {
      localStorage.removeItem(LOCAL_PROFILE_KEY);
    }
    setProfileMenuOpen(false);
    setProfile(null);
  }

  if (inAuthCallback) {
    return (
      <AuthCallbackView
        onComplete={async (session) => {
          if (session?.user) {
            setSupabaseAccessToken(session.access_token);
            const p = await loadSupabaseProfile(session.user.id, session.user.email || '');
            setProfile(p);
          }
          setInAuthCallback(false);
        }}
      />
    );
  }

  if (!authReady) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-[#070B14] flex items-center justify-center text-sm text-slate-500 dark:text-slate-400">
        Initializing NovaTrade AI workspace...
      </div>
    );
  }

  if (!profile) {
    return (
      <AuthGateView
        onAuthenticatedLocal={(email, displayName) => {
          const local: UserProfile = {
            id: 'local-research-session',
            email,
            displayName,
            role: 'trader',
            preferredCurrency: 'USD',
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
            authMode: 'local-preview',
          };
          localStorage.setItem(LOCAL_PROFILE_KEY, JSON.stringify(local));
          setProfile(local);
        }}
      />
    );
  }

  const pendingProposals = proposals.filter((p) => p.status === 'PENDING_APPROVAL');
  const activeNavTitle = NAV_ITEMS.find((n) => n.id === activeNav)?.label || 'Overview';
  const unreadCount = Math.max(0, activity.length - lastSeenActivityCount);
  const actionableSignalsCount = signals.filter((s) => s.direction === 'CALL' || s.direction === 'PUT').length;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#070B14] text-slate-900 dark:text-slate-100 flex overflow-x-hidden relative">
      {/* Subtle Ambient Gradient Glow */}
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(79,70,229,0.12),transparent_48%),radial-gradient(ellipse_at_bottom_left,rgba(37,99,235,0.1),transparent_48%)]" />

      {/* Desktop Sidebar (10 Navigation Items) */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col border-r border-slate-200 dark:border-indigo-500/20 bg-white/90 dark:bg-[#0A1121]/90 backdrop-blur-xl shrink-0 relative z-20">
        <div className="px-5 py-5 border-b border-slate-200 dark:border-indigo-500/20">
          <div className="text-base font-bold tracking-tight bg-gradient-to-r from-blue-600 to-indigo-500 dark:from-blue-400 dark:to-purple-400 bg-clip-text text-transparent">
            NovaTrade AI
          </div>
          <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">Autonomous Paper Terminal</p>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeNav === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveNav(item.id)}
                className={`w-full min-h-10 flex items-center gap-3 rounded-xl px-3 py-2 text-xs font-medium whitespace-nowrap transition-all ${
                  active
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-600/20'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-indigo-950/50 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-200 dark:border-indigo-500/20 text-[11px] text-slate-500 dark:text-slate-400 space-y-1">
          <div>Execution · Paper Only</div>
          <div>Supabase · {health?.supabase.clientConfigured ? 'Connected' : 'Pending Project Keys'}</div>
          <div>AI Loop · {autoArmed ? 'Armed' : 'Standby'}</div>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm" onClick={() => setMobileMenuOpen(false)} />
          <aside className="relative w-72 max-w-[82vw] bg-white dark:bg-[#0A1121] border-r border-slate-200 dark:border-indigo-500/20 flex flex-col z-10">
            <div className="flex items-center justify-between px-4 py-4 border-b border-slate-200 dark:border-indigo-500/20">
              <span className="text-base font-bold text-slate-900 dark:text-white">NovaTrade AI</span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="min-h-11 min-w-11 flex items-center justify-center rounded-xl text-slate-500 hover:text-slate-900 dark:hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto p-3 space-y-1">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = activeNav === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setActiveNav(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full min-h-11 flex items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-medium whitespace-nowrap ${
                      active
                        ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-indigo-950/50'
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </aside>
        </div>
      )}

      {/* Main Column */}
      <div className="flex-1 flex flex-col min-w-0 relative z-10">
        {/* Compact Top Header (<= 7.5% mobile height) */}
        <header className="sticky top-0 z-30 h-14 sm:h-16 border-b border-slate-200 dark:border-indigo-500/20 bg-white/90 dark:bg-[#0A1121]/85 backdrop-blur-xl px-3 sm:px-6 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden min-h-11 min-w-11 flex items-center justify-center rounded-xl border border-slate-200 dark:border-indigo-500/20 text-slate-700 dark:text-slate-300"
              aria-label="Open navigation"
            >
              <Menu className="h-5 w-5" />
            </button>
            <h1 className="text-sm sm:text-base font-semibold text-slate-900 dark:text-white truncate">
              {activeNavTitle}
            </h1>
          </div>

          <div className="hidden xl:flex items-center gap-4 text-xs text-slate-500 dark:text-slate-400 whitespace-nowrap">
            <span>Mode: {mode.toUpperCase()}</span>
            <span>·</span>
            <span>IQ Option: {brokerStatus?.connected ? 'Practice Connected' : 'Disconnected'}</span>
            <span>·</span>
            <span>Risk: {riskStatus?.allowed ? 'Clear' : 'Paused'}</span>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Theme Toggle */}
            <button
              type="button"
              onClick={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
              className="min-h-10 min-w-10 flex items-center justify-center rounded-xl border border-slate-200 dark:border-indigo-500/20 bg-slate-50 dark:bg-[#0E1629] text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label="Toggle Light/Dark theme"
            >
              {theme === 'dark' ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4 text-indigo-600" />}
            </button>

            {/* Notification Center */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setNotifOpen((v) => !v);
                  setProfileMenuOpen(false);
                  setLastSeenActivityCount(activity.length);
                }}
                className="min-h-10 min-w-10 flex items-center justify-center rounded-xl border border-slate-200 dark:border-indigo-500/20 bg-slate-50 dark:bg-[#0E1629] text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 relative"
                aria-label="Notifications"
              >
                <Bell className="h-4 w-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 h-4 min-w-4 rounded-full bg-blue-600 px-1 text-[10px] font-semibold text-white flex items-center justify-center">
                    {Math.min(9, unreadCount)}
                  </span>
                )}
              </button>

              {notifOpen && (
                <div className="absolute right-0 mt-2 w-80 max-w-[88vw] rounded-2xl border border-slate-200 dark:border-indigo-500/25 bg-white dark:bg-[#0E1629] p-4 shadow-2xl z-50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-slate-900 dark:text-white">Notification Center</span>
                    <button type="button" onClick={() => setNotifOpen(false)} className="text-xs text-slate-400 hover:text-white">
                      Close
                    </button>
                  </div>
                  <div className="max-h-64 overflow-y-auto divide-y divide-slate-200 dark:divide-slate-800 text-xs">
                    {activity.length === 0 ? (
                      <p className="py-4 text-center text-slate-500">No recent events.</p>
                    ) : (
                      activity.slice(0, 10).map((ev) => (
                        <div key={ev.id} className="py-2">
                          <div className="flex items-center justify-between text-[11px] text-slate-500">
                            <span className="font-medium text-blue-600 dark:text-indigo-300">{ev.eventType}</span>
                            <span className="font-mono">{new Date(ev.createdAt).toLocaleTimeString()}</span>
                          </div>
                          <p className="mt-0.5 text-slate-700 dark:text-slate-300">{ev.summary}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* User Profile Menu */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setProfileMenuOpen((v) => !v);
                  setNotifOpen(false);
                }}
                className="min-h-10 inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-indigo-500/20 bg-slate-50 dark:bg-[#0E1629] px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200"
              >
                <User className="h-3.5 w-3.5 text-indigo-500" />
                <span className="hidden sm:inline max-w-[100px] truncate">{profile.displayName}</span>
                <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
              </button>

              {profileMenuOpen && (
                <div className="absolute right-0 mt-2 w-60 rounded-2xl border border-slate-200 dark:border-indigo-500/25 bg-white dark:bg-[#0E1629] p-2 shadow-2xl z-50 text-xs">
                  <div className="px-3 py-2 border-b border-slate-200 dark:border-slate-800">
                    <p className="font-semibold text-slate-900 dark:text-white truncate">{profile.displayName}</p>
                    <p className="text-[11px] text-slate-500 truncate">{profile.email}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveNav('settings');
                      setProfileMenuOpen(false);
                    }}
                    className="w-full min-h-10 flex items-center gap-2 rounded-xl px-3 py-2 text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <Sliders className="h-3.5 w-3.5" /> Settings &amp; Profile
                  </button>
                  <button
                    type="button"
                    onClick={handleSignOut}
                    className="w-full min-h-10 flex items-center gap-2 rounded-xl px-3 py-2 text-left text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30"
                  >
                    <LogOut className="h-3.5 w-3.5" /> Sign Out
                  </button>
                </div>
              )}
            </div>

            {/* Emergency Stop Button */}
            <button
              type="button"
              disabled={busy}
              onClick={() => setConfirmState({ type: 'emergency-stop', payload: !riskStatus?.emergencyStop })}
              className={`min-h-10 rounded-xl px-3 py-2 text-xs font-semibold whitespace-nowrap transition-colors ${
                riskStatus?.emergencyStop
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  : 'bg-red-600 hover:bg-red-500 text-white'
              }`}
            >
              {riskStatus?.emergencyStop ? 'Resume Guard' : 'Emergency Stop'}
            </button>
          </div>
        </header>

        {/* Main View Area (padded for Android bottom bar on < lg) */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 pb-24 lg:pb-8 space-y-6 max-w-[1380px] w-full mx-auto">
          {!isSupabaseConfigured && (
            <div className="rounded-2xl border border-amber-300 dark:border-amber-800/70 bg-amber-50 dark:bg-amber-950/30 px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs text-amber-900 dark:text-amber-200">
              <div className="flex items-center gap-2">
                <ShieldAlert className="h-4 w-4 text-amber-600 dark:text-amber-400 shrink-0" />
                <span>
                  Supabase project not yet connected (<code className="font-mono">VITE_SUPABASE_URL</code> /{' '}
                  <code className="font-mono">VITE_SUPABASE_ANON_KEY</code> pending). Running with local persistence.
                </span>
              </div>
              <button
                type="button"
                onClick={() => setActiveNav('settings')}
                className="text-amber-800 dark:text-amber-300 underline hover:opacity-80 whitespace-nowrap"
              >
                Account &amp; Settings
              </button>
            </div>
          )}

          {/* OVERVIEW */}
          {activeNav === 'overview' && (
            <div className="space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-semibold text-slate-900 dark:text-white">NovaTrade Command Overview</h2>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Live quantitative market intelligence, paper simulation portfolio, and server-side risk controls.
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setActiveNav('scanner')}
                    className="min-h-11 rounded-xl border border-slate-300 dark:border-indigo-500/30 bg-white dark:bg-[#0E1629] px-4 py-2 text-xs font-semibold text-slate-800 dark:text-slate-200 whitespace-nowrap"
                  >
                    Open AI Scanner
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveNav('live-markets')}
                    className="min-h-11 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 px-4 py-2 text-xs font-semibold text-white whitespace-nowrap shadow-md shadow-blue-600/20"
                  >
                    Open Live Markets
                  </button>
                </div>
              </div>

              {/* 6 Summary Cards: Account Balance, Today's P&L, Total Trades, Win Rate, Active Signals, AI Status */}
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
                <div className={`${GLASS_CARD} p-4`}>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Account Balance</p>
                  <p className="mt-2 text-xl sm:text-2xl font-semibold font-mono tabular-nums text-slate-900 dark:text-white">
                    ${(analytics?.currentVirtualBalance ?? 10000).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                  <p className="mt-1 text-[11px] text-slate-500">Paper virtual equity</p>
                </div>

                <div className={`${GLASS_CARD} p-4`}>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Today&apos;s P&amp;L</p>
                  <p
                    className={`mt-2 text-xl sm:text-2xl font-semibold font-mono tabular-nums ${
                      (analytics?.todayPnl ?? 0) >= 0
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : 'text-red-600 dark:text-red-400'
                    }`}
                  >
                    {(analytics?.todayPnl ?? 0) >= 0 ? '+' : ''}
                    ${(analytics?.todayPnl ?? 0).toFixed(2)}
                  </p>
                  <p className="mt-1 text-[11px] text-slate-500">{analytics?.todayTrades ?? 0} settled today</p>
                </div>

                <div className={`${GLASS_CARD} p-4`}>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Total Trades</p>
                  <p className="mt-2 text-xl sm:text-2xl font-semibold font-mono tabular-nums text-slate-900 dark:text-white">
                    {analytics?.totalTrades ?? 0}
                  </p>
                  <p className="mt-1 text-[11px] text-slate-500">{activeTrades.length} active open</p>
                </div>

                <div className={`${GLASS_CARD} p-4`}>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Win Rate</p>
                  <p className="mt-2 text-xl sm:text-2xl font-semibold font-mono tabular-nums text-slate-900 dark:text-white">
                    {analytics?.winRatePct != null ? `${analytics.winRatePct}%` : '—'}
                  </p>
                  <p className="mt-1 text-[11px] text-slate-500">
                    {analytics?.wins ?? 0}W / {analytics?.losses ?? 0}L settled
                  </p>
                </div>

                <div className={`${GLASS_CARD} p-4`}>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Active Signals</p>
                  <p className="mt-2 text-xl sm:text-2xl font-semibold font-mono tabular-nums text-indigo-600 dark:text-indigo-300">
                    {actionableSignalsCount}
                  </p>
                  <p className="mt-1 text-[11px] text-slate-500">{signals.length} total scanned</p>
                </div>

                <div className={`${GLASS_CARD} p-4`}>
                  <p className="text-xs text-slate-500 dark:text-slate-400">AI Status</p>
                  <p
                    className={`mt-2 text-xl sm:text-2xl font-semibold ${
                      !riskStatus?.allowed
                        ? 'text-red-600 dark:text-red-400'
                        : autoArmed
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-blue-600 dark:text-blue-400'
                    }`}
                  >
                    {!riskStatus?.allowed ? 'Risk Halted' : autoArmed ? 'Autonomous' : mode.toUpperCase()}
                  </p>
                  <p className="mt-1 text-[11px] text-slate-500 truncate">
                    {health?.scheduler.lastCycleSummary || `Interval ${aiSettings?.scanIntervalSeconds ?? 60}s`}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className={`lg:col-span-2 ${GLASS_CARD} p-5`}>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Paper Equity Performance</h3>
                    <button
                      type="button"
                      onClick={() => setActiveNav('analytics')}
                      className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
                    >
                      Daily / Weekly / Monthly Analytics
                    </button>
                  </div>
                  <EquityChart points={analytics?.equityCurve || []} />
                </div>

                <div className={`${GLASS_CARD} p-5 flex flex-col justify-between`}>
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Quick Automation Control</h3>
                    <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      Server-side autonomous scheduler monitors {aiSettings?.enabledAssets.length ?? 6} enabled assets every{' '}
                      {aiSettings?.scanIntervalSeconds ?? 60}s and settles expired paper positions automatically.
                    </p>
                  </div>
                  <div className="space-y-2.5 mt-4">
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => setConfirmState({ type: 'arm-auto', payload: !autoArmed })}
                      className={`w-full min-h-11 rounded-xl py-2.5 px-4 text-xs font-semibold text-white transition-colors ${
                        autoArmed ? 'bg-amber-600 hover:bg-amber-500' : 'bg-gradient-to-r from-blue-600 to-indigo-600'
                      }`}
                    >
                      {autoArmed ? 'Pause Automatic Mode' : 'Arm Automatic Mode'}
                    </button>
                    <button
                      type="button"
                      disabled={busy}
                      onClick={handleRunAutoCycleNow}
                      className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-indigo-500/20 bg-slate-50 dark:bg-[#070B14] hover:bg-slate-100 dark:hover:bg-slate-800 py-2.5 px-4 text-xs font-medium text-slate-700 dark:text-slate-200"
                    >
                      Trigger Autonomous Cycle Now
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveNav('paper-trading')}
                      className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-indigo-500/20 bg-slate-50 dark:bg-[#070B14] hover:bg-slate-100 dark:hover:bg-slate-800 py-2.5 px-4 text-xs font-medium text-slate-700 dark:text-slate-200"
                    >
                      Open Paper Trading Desk
                    </button>
                  </div>
                </div>
              </div>

              <div className={`${GLASS_CARD} p-5`}>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Latest Quantitative Signals</h3>
                  <button
                    type="button"
                    onClick={() => setActiveNav('signals')}
                    className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    View All ({signals.length})
                  </button>
                </div>
                {signals.length === 0 ? (
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    No signals generated yet. Open Live Markets or AI Scanner to evaluate live candles.
                  </p>
                ) : (
                  <div className="divide-y divide-slate-200 dark:divide-slate-800">
                    {signals.slice(0, 5).map((s) => (
                      <div key={s.id} className="py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
                        <div className="flex items-center gap-3">
                          <span
                            className={`font-semibold ${
                              s.direction === 'CALL'
                                ? 'text-emerald-600 dark:text-emerald-400'
                                : s.direction === 'PUT'
                                  ? 'text-red-600 dark:text-red-400'
                                  : 'text-amber-600 dark:text-amber-400'
                            }`}
                          >
                            {s.direction}
                          </span>
                          <span className="font-semibold text-slate-900 dark:text-white">{s.symbol}</span>
                          <span className="text-slate-500 dark:text-slate-400">
                            {s.timeframe} · {s.provider}
                          </span>
                        </div>
                        <div className="font-mono tabular-nums text-slate-600 dark:text-slate-300">
                          Confidence {s.confidenceScore ?? s.score}/100 · {new Date(s.timestamp).toLocaleTimeString()}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* AI SCANNER */}
          {activeNav === 'scanner' && (
            <MarketScannerView
              assets={assets}
              rows={scannerRows}
              timeframe={selectedTimeframe}
              scanning={scanning}
              scanProgress={scanProgress}
              onTimeframeChange={setSelectedTimeframe}
              onRunScan={handleProgressiveScan}
              onSelectAsset={(sym) => {
                setSelectedSymbol(sym);
                setActiveNav('live-markets');
              }}
            />
          )}

          {/* LIVE MARKETS TERMINAL */}
          {activeNav === 'live-markets' && (
            <div className="space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-3">
                  <select
                    value={selectedSymbol}
                    onChange={(e) => setSelectedSymbol(e.target.value)}
                    className="min-h-11 rounded-xl border border-slate-300 dark:border-indigo-500/25 bg-white dark:bg-[#0E1629] px-3 py-2 text-sm font-semibold text-slate-900 dark:text-white"
                  >
                    {groupedAssets.FOREX.length > 0 && (
                      <optgroup label="Forex Pairs (FX Feed)">
                        {groupedAssets.FOREX.map((a) => (
                          <option key={a.symbol} value={a.symbol}>
                            {a.symbol} — {a.name}
                          </option>
                        ))}
                      </optgroup>
                    )}
                    {groupedAssets.CRYPTO.length > 0 && (
                      <optgroup label="Cryptocurrencies (Spot Crypto)">
                        {groupedAssets.CRYPTO.map((a) => (
                          <option key={a.symbol} value={a.symbol}>
                            {a.symbol} — {a.name}
                          </option>
                        ))}
                      </optgroup>
                    )}
                    {groupedAssets.COMMODITY.length > 0 && (
                      <optgroup label="Commodities (Futures Feed)">
                        {groupedAssets.COMMODITY.map((a) => (
                          <option key={a.symbol} value={a.symbol}>
                            {a.symbol} — {a.name}
                          </option>
                        ))}
                      </optgroup>
                    )}
                  </select>

                  <div className="flex rounded-xl border border-slate-200 dark:border-indigo-500/20 bg-white dark:bg-[#0E1629] p-1">
                    {(['1m', '5m', '15m', '1h'] as Timeframe[]).map((tf) => (
                      <button
                        key={tf}
                        type="button"
                        onClick={() => setSelectedTimeframe(tf)}
                        className={`min-h-9 px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap ${
                          selectedTimeframe === tf
                            ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white'
                            : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                        }`}
                      >
                        {tf}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    disabled={candleLoading}
                    onClick={() => loadCandles(selectedSymbol, selectedTimeframe)}
                    className="min-h-11 inline-flex items-center gap-1.5 rounded-xl border border-slate-300 dark:border-indigo-500/25 bg-white dark:bg-[#0E1629] hover:bg-slate-50 dark:hover:bg-slate-800 px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap"
                  >
                    <RefreshCw className={`h-3.5 w-3.5 ${candleLoading ? 'animate-spin' : ''}`} /> Refresh
                  </button>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={handleRunAnalysis}
                    className="min-h-11 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-50 px-4 py-2 text-xs font-semibold text-white whitespace-nowrap shadow-md shadow-blue-600/20"
                  >
                    <Play className="h-3.5 w-3.5" /> {busy ? 'Analysing...' : 'Run Quantitative Analysis'}
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                <div className="xl:col-span-2 space-y-6">
                  <div className={`${GLASS_CARD} p-5`}>
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                      <div>
                        <h2 className="text-base font-semibold text-slate-900 dark:text-white">
                          {selectedAssetMeta.name} · {selectedAssetMeta.instrumentType}
                        </h2>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          Provider: {candleFeed?.provider || 'Checking...'} · Status:{' '}
                          <span
                            className={
                              candleFeed?.marketStatus === 'OPEN'
                                ? 'text-emerald-600 dark:text-emerald-400 font-medium'
                                : 'text-amber-600 dark:text-amber-400 font-medium'
                            }
                          >
                            {candleFeed?.marketStatus || 'CONNECTING'}
                          </span>{' '}
                          · Updated {candleFeed?.fetchedAt ? new Date(candleFeed.fetchedAt).toLocaleTimeString() : '—'}
                        </p>
                      </div>
                      <div className="text-right font-mono tabular-nums">
                        <div className="text-xl font-semibold text-slate-900 dark:text-white">
                          {candleFeed?.currentPrice != null
                            ? candleFeed.currentPrice.toFixed(selectedAssetMeta.decimals)
                            : '—'}
                        </div>
                        {candleFeed?.priceChangePct != null && (
                          <div
                            className={`text-xs ${
                              candleFeed.priceChangePct >= 0
                                ? 'text-emerald-600 dark:text-emerald-400'
                                : 'text-red-600 dark:text-red-400'
                            }`}
                          >
                            {candleFeed.priceChangePct >= 0 ? '+' : ''}
                            {candleFeed.priceChangePct.toFixed(3)}% window
                          </div>
                        )}
                      </div>
                    </div>

                    <CandlestickChart
                      symbol={selectedSymbol}
                      timeframe={selectedTimeframe}
                      candles={candleFeed?.candles || []}
                      overlays={candleFeed?.overlays}
                      indicators={currentAnalysis?.symbol === selectedSymbol ? currentAnalysis.indicators : null}
                      decimals={selectedAssetMeta.decimals}
                      loading={candleLoading}
                      error={candleError}
                    />
                  </div>

                  {/* Quantitative Breakdown */}
                  <div className={`${GLASS_CARD} p-5 space-y-4`}>
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Quantitative Decision</p>
                        <div className="mt-1 flex items-center gap-3">
                          <span
                            className={`text-2xl font-bold ${
                              currentAnalysis?.direction === 'CALL'
                                ? 'text-emerald-600 dark:text-emerald-400'
                                : currentAnalysis?.direction === 'PUT'
                                  ? 'text-red-600 dark:text-red-400'
                                  : 'text-amber-600 dark:text-amber-400'
                            }`}
                          >
                            {currentAnalysis?.direction || 'WAIT'}
                          </span>
                          <span className="text-sm font-mono tabular-nums text-slate-700 dark:text-slate-300">
                            Confidence {currentAnalysis?.confidenceScore ?? currentAnalysis?.score ?? 0}/100
                          </span>
                        </div>
                      </div>
                      <div className="text-right text-xs text-slate-500 dark:text-slate-400">
                        <div>
                          Suggested Expiry:{' '}
                          <strong className="font-mono text-slate-900 dark:text-white">
                            {Math.round((currentAnalysis?.suggestedExpirySeconds || 180) / 60)}m
                          </strong>
                        </div>
                        <div className="mt-0.5">
                          Risk:{' '}
                          <span className="font-semibold text-slate-800 dark:text-slate-200">
                            {currentAnalysis?.riskAssessment?.level || 'MODERATE'}
                          </span>{' '}
                          · MTF ({currentAnalysis?.mtf?.higherTimeframe || '5m'}): {currentAnalysis?.mtf?.alignment || 'NEUTRAL'}
                        </div>
                      </div>
                    </div>

                    {currentAnalysis?.indicators && (
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 border-t border-slate-200 dark:border-slate-800 pt-4 text-xs">
                        <div>
                          <span className="text-slate-500">Trend</span>
                          <p className="mt-0.5 font-medium text-slate-900 dark:text-white">{currentAnalysis.indicators.trend}</p>
                        </div>
                        <div>
                          <span className="text-slate-500">RSI (14)</span>
                          <p className="mt-0.5 font-mono tabular-nums text-slate-900 dark:text-white">{currentAnalysis.indicators.rsi14}</p>
                        </div>
                        <div>
                          <span className="text-slate-500">MACD Hist</span>
                          <p className="mt-0.5 font-mono tabular-nums text-slate-900 dark:text-white">
                            {currentAnalysis.indicators.macdHistogram.toFixed(6)}
                          </p>
                        </div>
                        <div>
                          <span className="text-slate-500">Volatility</span>
                          <p className="mt-0.5 font-medium text-slate-900 dark:text-white">
                            {currentAnalysis.indicators.volatilityRegime} ({currentAnalysis.indicators.atrPct}%)
                          </p>
                        </div>
                        <div>
                          <span className="text-slate-500">EMA 9 / 21 / 50</span>
                          <p className="mt-0.5 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                            {currentAnalysis.indicators.ema9.toFixed(4)} / {currentAnalysis.indicators.ema21.toFixed(4)}
                          </p>
                        </div>
                        <div>
                          <span className="text-slate-500">Bollinger %B</span>
                          <p className="mt-0.5 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                            {currentAnalysis.indicators.bbPercentB} ({currentAnalysis.indicators.bbBandwidthPct}%)
                          </p>
                        </div>
                        <div>
                          <span className="text-slate-500">Nearest Support</span>
                          <p className="mt-0.5 font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
                            {currentAnalysis.indicators.nearestSupport.toFixed(selectedAssetMeta.decimals)}
                          </p>
                        </div>
                        <div>
                          <span className="text-slate-500">Nearest Resistance</span>
                          <p className="mt-0.5 font-mono tabular-nums text-red-600 dark:text-red-400">
                            {currentAnalysis.indicators.nearestResistance.toFixed(selectedAssetMeta.decimals)}
                          </p>
                        </div>
                      </div>
                    )}

                    {currentAnalysis && (
                      <div className="border-t border-slate-200 dark:border-slate-800 pt-3 space-y-2">
                        <ul className="space-y-1 text-xs text-slate-700 dark:text-slate-300 list-disc pl-4">
                          {currentAnalysis.reasons.map((r, i) => (
                            <li key={i}>{r}</li>
                          ))}
                        </ul>
                        {currentAnalysis.aiExplanation?.summary && (
                          <div className="rounded-xl border border-indigo-500/25 bg-indigo-50 dark:bg-indigo-950/30 p-3 text-xs">
                            <p className="font-semibold text-indigo-700 dark:text-indigo-300">Gemini Analyst Commentary</p>
                            <p className="mt-1 text-slate-700 dark:text-slate-300 leading-relaxed">{currentAnalysis.aiExplanation.summary}</p>
                            {currentAnalysis.aiExplanation.riskNote && (
                              <p className="mt-1 text-slate-500 dark:text-slate-400">{currentAnalysis.aiExplanation.riskNote}</p>
                            )}
                          </div>
                        )}
                        <p className="text-[11px] text-slate-500">{currentAnalysis.warning}</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Right Column: Three Modes & Quick Paper Ticket */}
                <div className="space-y-6">
                  <div className={`${GLASS_CARD} p-5 space-y-4`}>
                    <div>
                      <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Operating Mode</p>
                      <div className="mt-2 grid grid-cols-3 gap-1 rounded-xl border border-slate-200 dark:border-indigo-500/20 bg-slate-100 dark:bg-[#070B14] p-1">
                        {(['signals', 'assisted', 'automatic'] as OperatingMode[]).map((m) => (
                          <button
                            key={m}
                            type="button"
                            onClick={() => handleModeChange(m)}
                            className={`min-h-10 rounded-lg py-2 text-xs font-semibold capitalize whitespace-nowrap transition-colors ${
                              mode === m
                                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white'
                                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                            }`}
                          >
                            {m}
                          </button>
                        ))}
                      </div>
                    </div>

                    {mode === 'signals' && (
                      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#070B14] p-3.5 text-xs text-slate-600 dark:text-slate-300 space-y-1.5">
                        <p className="font-semibold text-slate-900 dark:text-white">Mode A: Quantitative Signals</p>
                        <p className="leading-relaxed">
                          Evaluates multi-indicator confluence and higher-timeframe alignment to generate CALL, PUT, or WAIT signals.
                        </p>
                      </div>
                    )}

                    {mode === 'assisted' && (
                      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#070B14] p-3.5 text-xs space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-slate-900 dark:text-white">Mode B: Assisted Trading</span>
                          <span className="text-slate-500">Approval Required</span>
                        </div>
                        <button
                          type="button"
                          disabled={busy}
                          onClick={handleCreateAssistedProposal}
                          className="w-full min-h-10 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-50 py-2 px-3 text-xs font-semibold text-white"
                        >
                          Generate Assisted Proposal
                        </button>

                        {pendingProposals.map((prop) => (
                          <div key={prop.id} className="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#0E1629] p-3 space-y-2">
                            <div className="flex items-center justify-between font-medium">
                              <span className={prop.direction === 'CALL' ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}>
                                {prop.direction} {prop.symbol} ({prop.timeframe})
                              </span>
                              <span className="font-mono tabular-nums text-slate-900 dark:text-white">${prop.recommendedAmount}</span>
                            </div>
                            <p className="text-[11px] text-slate-500">Confidence {prop.score}/100 · Entry {prop.entryPrice ?? '—'}</p>
                            <div className="flex gap-2">
                              <button
                                type="button"
                                disabled={busy}
                                onClick={() => handleApproveProposal(prop.id)}
                                className="flex-1 min-h-9 inline-flex items-center justify-center gap-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-medium text-white"
                              >
                                <CheckCircle2 className="h-3.5 w-3.5" /> Approve
                              </button>
                              <button
                                type="button"
                                disabled={busy}
                                onClick={() => handleRejectProposal(prop.id)}
                                className="flex-1 min-h-9 inline-flex items-center justify-center gap-1 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-300"
                              >
                                <XCircle className="h-3.5 w-3.5" /> Reject
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {mode === 'automatic' && (
                      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#070B14] p-3.5 text-xs space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
                            <Bot className="h-4 w-4 text-blue-500" /> Mode C: Autonomous Paper
                          </span>
                          <span className={autoArmed ? 'text-emerald-600 dark:text-emerald-400 font-semibold' : 'text-amber-600 dark:text-amber-400 font-semibold'}>
                            {autoArmed ? 'ARMED' : 'PAUSED'}
                          </span>
                        </div>
                        <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                          Continuously scans enabled instruments on the server, opens validated paper trades, and auto-settles expiries.
                        </p>
                        {riskStatus?.autoPausedReason && (
                          <p className="text-red-600 dark:text-red-400">Paused: {riskStatus.autoPausedReason}</p>
                        )}
                        <div className="flex gap-2">
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => setConfirmState({ type: 'arm-auto', payload: !autoArmed })}
                            className={`flex-1 min-h-10 rounded-xl py-2 px-3 text-xs font-semibold text-white ${
                              autoArmed ? 'bg-amber-600 hover:bg-amber-500' : 'bg-gradient-to-r from-blue-600 to-indigo-600'
                            }`}
                          >
                            {autoArmed ? 'Pause Auto' : 'Arm Auto'}
                          </button>
                          <button
                            type="button"
                            disabled={busy}
                            onClick={handleRunAutoCycleNow}
                            className="flex-1 min-h-10 rounded-xl border border-slate-300 dark:border-slate-700 py-2 px-3 text-xs font-medium text-slate-700 dark:text-slate-200"
                          >
                            Run Cycle
                          </button>
                        </div>
                      </div>
                    )}

                    <div className="border-t border-slate-200 dark:border-slate-800 pt-4 space-y-3">
                      <p className="text-xs font-medium text-slate-700 dark:text-slate-300">Paper Trade Ticket (Simulation Only)</p>
                      <div>
                        <label className="block text-[11px] text-slate-500 mb-1">
                          Stake Amount (Max ${riskStatus?.limits.maxTradeAmount ?? 100})
                        </label>
                        <input
                          type="number"
                          min={1}
                          max={riskStatus?.limits.maxTradeAmount ?? 1000}
                          value={manualStake}
                          onChange={(e) => setManualStake(Math.max(1, Number(e.target.value)))}
                          className="w-full min-h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#070B14] px-3 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => handleOpenManualPaperTrade(selectedSymbol, 'CALL', manualStake)}
                          className="min-h-11 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 py-2.5 text-xs font-semibold text-white"
                        >
                          Paper CALL
                        </button>
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => handleOpenManualPaperTrade(selectedSymbol, 'PUT', manualStake)}
                          className="min-h-11 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-50 py-2.5 text-xs font-semibold text-white"
                        >
                          Paper PUT
                        </button>
                      </div>
                      <p className="text-[11px] text-slate-500">
                        Binary options contracts: {selectedAssetMeta.binaryOptionsOfferedByBroker ? 'Available via connected broker' : 'Disabled (no live broker feed)'}.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeNav === 'signals' && (
            <SignalsView
              signals={signals}
              onSelectSymbol={(sym) => {
                setSelectedSymbol(sym);
                setActiveNav('live-markets');
              }}
            />
          )}

          {activeNav === 'paper-trading' && (
            <PaperTradingDeskView
              analytics={analytics}
              assets={assets}
              trades={activeTrades}
              proposals={proposals}
              mode={mode}
              autoArmed={autoArmed}
              riskStatus={riskStatus}
              selectedSymbol={selectedSymbol}
              selectedTimeframe={selectedTimeframe}
              busy={busy}
              onSelectSymbol={setSelectedSymbol}
              onModeChange={handleModeChange}
              onUpdateStartingBalance={handleUpdateStartingBalance}
              onOpenManualTrade={handleOpenManualPaperTrade}
              onCreateAssistedProposal={handleCreateAssistedProposal}
              onApproveProposal={handleApproveProposal}
              onRejectProposal={handleRejectProposal}
              onRequestArmAuto={() => setConfirmState({ type: 'arm-auto', payload: !autoArmed })}
              onRunAutoCycle={handleRunAutoCycleNow}
              onSettle={handleSettleTrade}
              onCancel={handleCancelTrade}
            />
          )}

          {activeNav === 'history' && <TradeHistoryView trades={paperTrades} />}

          {activeNav === 'analytics' && <AnalyticsView analytics={analytics} assets={assets} riskStatus={riskStatus} />}

          {activeNav === 'risk' && (
            <RiskManagementView
              riskStatus={riskStatus}
              busy={busy}
              onSaveRisk={handleSaveRisk}
              onRequestEmergencyStop={(engaged) => setConfirmState({ type: 'emergency-stop', payload: engaged })}
              onRequestResetDaily={() => setConfirmState({ type: 'reset-daily' })}
            />
          )}

          {activeNav === 'brokers' && (
            <BrokerConnectionsView
              broker={brokerStatus}
              catalog={brokerCatalog}
              busy={busy}
              onRefresh={refreshPlatformState}
              onConnectIq={async () => {
                setBusy(true);
                try {
                  const r = await apiRequest<{ message: string }>('/api/broker/iq/connect', {
                    method: 'POST',
                    headers: authHeaders,
                    body: JSON.stringify({}),
                  });
                  pushToast('info', 'IQ Option Connector', r.message);
                  await refreshPlatformState();
                } catch (err) {
                  pushToast('error', 'IQ Option Connection Failed', err instanceof Error ? err.message : 'Unable to connect.');
                } finally {
                  setBusy(false);
                }
              }}
              onDisconnectIq={async () => {
                setBusy(true);
                try {
                  const r = await apiRequest<{ message: string }>('/api/broker/iq/disconnect', {
                    method: 'POST',
                    headers: authHeaders,
                    body: JSON.stringify({}),
                  });
                  pushToast('info', 'IQ Option Disconnected', r.message);
                  await refreshPlatformState();
                } finally {
                  setBusy(false);
                }
              }}
              onFetchIqAssets={async () => {
                const res = await apiRequest<{ assets: Array<{ symbol: string; category: string; open: boolean }> }>('/api/broker/iq/assets', {
                  headers: authHeaders,
                });
                return res.assets;
              }}
              onFetchIqHistory={async () => {
                return apiRequest<{ supported: boolean; trades: Array<Record<string, unknown>>; note: string }>('/api/broker/iq/history', {
                  headers: authHeaders,
                });
              }}
            />
          )}

          {activeNav === 'settings' && (
            <SettingsView
              aiSettings={aiSettings}
              assets={assets}
              profile={profile}
              activity={activity}
              theme={theme}
              busy={busy}
              onToggleTheme={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
              onSaveAiSettings={handleSaveAiSettings}
              onUpdateProfile={(p) => {
                setProfile(p);
                if (!isSupabaseConfigured) {
                  localStorage.setItem(LOCAL_PROFILE_KEY, JSON.stringify(p));
                }
                pushToast('success', 'Profile Saved', `Updated settings for ${p.displayName}.`);
              }}
              onSignOut={handleSignOut}
            />
          )}
        </main>
      </div>

      {/* Android Mobile Fixed Bottom Navigation Bar (h-16, <= 8.5% viewport height) */}
      <nav
        aria-label="Mobile primary navigation"
        className="lg:hidden fixed bottom-0 inset-x-0 z-40 h-16 border-t border-slate-200 dark:border-indigo-500/20 bg-white/95 dark:bg-[#0A1121]/95 backdrop-blur-xl grid grid-cols-5"
      >
        {[
          { id: 'overview' as NavSection, label: 'Overview', icon: LayoutDashboard },
          { id: 'scanner' as NavSection, label: 'Scanner', icon: Radar },
          { id: 'live-markets' as NavSection, label: 'Markets', icon: CandleIcon },
          { id: 'paper-trading' as NavSection, label: 'Paper', icon: Wallet },
        ].map((tab) => {
          const Icon = tab.icon;
          const active = activeNav === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                setActiveNav(tab.id);
                setMobileMoreOpen(false);
              }}
              className={`min-h-11 flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium ${
                active ? 'text-blue-600 dark:text-blue-400' : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
        <button
          type="button"
          onClick={() => setMobileMoreOpen((v) => !v)}
          className={`min-h-11 flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium ${
            ['signals', 'history', 'analytics', 'risk', 'brokers', 'settings'].includes(activeNav) || mobileMoreOpen
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <MoreHorizontal className="h-4 w-4" />
          <span>More</span>
        </button>
      </nav>

      {/* Mobile More Bottom Sheet */}
      {mobileMoreOpen && (
        <div className="lg:hidden fixed inset-0 z-40 flex items-end pb-16">
          <div className="fixed inset-0 bg-slate-950/60" onClick={() => setMobileMoreOpen(false)} />
          <div className="relative z-10 w-full rounded-t-2xl border-t border-slate-200 dark:border-indigo-500/25 bg-white dark:bg-[#0E1629] p-4 space-y-2 shadow-2xl">
            <div className="flex items-center justify-between px-1 pb-1">
              <span className="text-xs font-semibold text-slate-900 dark:text-white">Terminal Modules</span>
              <button type="button" onClick={() => setMobileMoreOpen(false)} className="text-xs text-slate-400">
                Close
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {NAV_ITEMS.filter((n) => ['signals', 'history', 'analytics', 'risk', 'brokers', 'settings'].includes(n.id)).map((item) => {
                const Icon = item.icon;
                const active = activeNav === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setActiveNav(item.id);
                      setMobileMoreOpen(false);
                    }}
                    className={`min-h-11 flex items-center gap-2.5 rounded-xl border px-3 py-2 text-xs font-medium ${
                      active
                        ? 'border-blue-500 bg-blue-500/15 text-blue-600 dark:text-blue-300'
                        : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification Stack */}
      {toasts.length > 0 && (
        <div className="fixed top-16 right-3 sm:right-6 z-50 w-80 max-w-[90vw] space-y-2 pointer-events-none">
          {toasts.map((t) => (
            <div
              key={t.id}
              className={`pointer-events-auto rounded-xl border p-3.5 shadow-xl backdrop-blur-xl text-xs transition-all ${
                t.kind === 'error'
                  ? 'border-red-300 dark:border-red-800/80 bg-white/95 dark:bg-[#1E1018]/95 text-red-800 dark:text-red-200'
                  : t.kind === 'success'
                    ? 'border-emerald-300 dark:border-emerald-800/80 bg-white/95 dark:bg-[#0D1E1B]/95 text-emerald-900 dark:text-emerald-200'
                    : t.kind === 'warning'
                      ? 'border-amber-300 dark:border-amber-800/80 bg-white/95 dark:bg-[#1E190E]/95 text-amber-900 dark:text-amber-200'
                      : 'border-indigo-300 dark:border-indigo-500/30 bg-white/95 dark:bg-[#0E1629]/95 text-slate-800 dark:text-slate-200'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-semibold">{t.title}</p>
                  <p className="mt-0.5 opacity-85 leading-relaxed">{t.message}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setToasts((prev) => prev.filter((item) => item.id !== t.id))}
                  className="opacity-60 hover:opacity-100"
                  aria-label="Dismiss toast"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Confirmation Dialogs */}
      <ConfirmDialog
        open={confirmState.type === 'emergency-stop'}
        title={confirmState.payload ? 'Engage Emergency Stop?' : 'Clear Emergency Stop?'}
        description={
          confirmState.payload
            ? 'Immediately pauses the autonomous paper trading scheduler and blocks all new paper entries until you clear the emergency stop.'
            : 'Restores paper trading eligibility subject to all daily loss, daily trade count, and consecutive loss caps.'
        }
        confirmLabel={confirmState.payload ? 'Engage Emergency Stop' : 'Clear Emergency Stop'}
        tone={confirmState.payload ? 'danger' : 'primary'}
        busy={busy}
        onCancel={() => setConfirmState({ type: null })}
        onConfirm={async () => {
          const val = Boolean(confirmState.payload);
          setConfirmState({ type: null });
          await executeEmergencyStop(val);
        }}
      />

      <ConfirmDialog
        open={confirmState.type === 'reset-daily'}
        title="Reset Daily Risk Counters?"
        description="Resets today's simulated daily loss, daily profit, daily trade count, and consecutive loss streak counters back to zero."
        confirmLabel="Reset Daily Counters"
        tone="warning"
        busy={busy}
        onCancel={() => setConfirmState({ type: null })}
        onConfirm={async () => {
          setConfirmState({ type: null });
          await executeResetDailyRisk();
        }}
      />

      <ConfirmDialog
        open={confirmState.type === 'arm-auto'}
        title={confirmState.payload ? 'Arm Autonomous Paper Mode?' : 'Pause Autonomous Paper Mode?'}
        description={
          confirmState.payload
            ? `Starts the server-side autonomous scheduler scanning ${aiSettings?.enabledAssets.length ?? 6} instruments every ${aiSettings?.scanIntervalSeconds ?? 60}s and opening validated PAPER trades within your risk limits. Real-money broker execution remains locked.`
            : 'Pauses autonomous paper trade scanning while keeping open trade expiry monitoring active.'
        }
        confirmLabel={confirmState.payload ? 'Arm Autonomous Mode' : 'Pause Autonomous Mode'}
        tone={confirmState.payload ? 'primary' : 'warning'}
        busy={busy}
        onCancel={() => setConfirmState({ type: null })}
        onConfirm={async () => {
          const val = Boolean(confirmState.payload);
          setConfirmState({ type: null });
          await executeToggleAutoArm(val);
        }}
      />
    </div>
  );
}
