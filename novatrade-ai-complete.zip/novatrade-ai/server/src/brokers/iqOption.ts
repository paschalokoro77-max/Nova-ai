import type {
  BrokerAdapter,
  BrokerAssetInfo,
  BrokerCandle,
  BrokerCapabilities,
  BrokerConnectorDiagnostics,
  BrokerStatusSnapshot,
  BrokerTradeHistoryResult,
} from './types.ts';

const IQ_LIMITATIONS = [
  'IQ Option does not provide an officially documented public retail trading API.',
  'The self-hosted iq-connector relies on the unofficial community iqoptionapi package (PRACTICE / read-only only).',
  'Accounts requiring 2FA, captcha verification, or restricted by jurisdiction cannot authenticate automatically.',
  'Real-money order execution remains locked until an authorised, tested broker integration is verified.',
];

export interface ParsedIqConnectorConfig {
  configured: boolean;
  url: string | null;
  urlValid: boolean;
  hadVarNamePrefix: boolean;
  isLocalhost: boolean;
  targetHost: string | null;
  tokenConfigured: boolean;
  warnings: string[];
}

export function parseIqConnectorConfig(rawInput = process.env.IQ_CONNECTOR_URL || ''): ParsedIqConnectorConfig {
  let raw = rawInput.trim();
  const tokenConfigured = Boolean((process.env.IQ_CONNECTOR_TOKEN || '').trim());
  if (!raw) {
    return {
      configured: false,
      url: null,
      urlValid: false,
      hadVarNamePrefix: false,
      isLocalhost: false,
      targetHost: null,
      tokenConfigured,
      warnings: [],
    };
  }

  // Strip wrapping quotes if user pasted quoted env string
  if ((raw.startsWith('"') && raw.endsWith('"')) || (raw.startsWith("'") && raw.endsWith("'"))) {
    raw = raw.slice(1, -1).trim();
  }

  const warnings: string[] = [];
  let hadVarNamePrefix = false;
  if (/^IQ_CONNECTOR_URL\s*=/i.test(raw)) {
    hadVarNamePrefix = true;
    raw = raw.replace(/^IQ_CONNECTOR_URL\s*=\s*/i, '').trim();
    if ((raw.startsWith('"') && raw.endsWith('"')) || (raw.startsWith("'") && raw.endsWith("'"))) {
      raw = raw.slice(1, -1).trim();
    }
    warnings.push(
      'IQ_CONNECTOR_URL contained the "IQ_CONNECTOR_URL=" variable name prefix. Store only the URL value (e.g. https://your-connector.example) in Settings > Secrets.'
    );
  }

  if (!raw) {
    return {
      configured: true,
      url: null,
      urlValid: false,
      hadVarNamePrefix,
      isLocalhost: false,
      targetHost: null,
      tokenConfigured,
      warnings: [...warnings, 'IQ_CONNECTOR_URL is empty after stripping the variable name prefix.'],
    };
  }

  try {
    const parsed = new URL(raw);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return {
        configured: true,
        url: null,
        urlValid: false,
        hadVarNamePrefix,
        isLocalhost: false,
        targetHost: null,
        tokenConfigured,
        warnings: [...warnings, 'IQ_CONNECTOR_URL must use http:// or https:// protocol.'],
      };
    }

    const host = parsed.hostname.toLowerCase();
    const isLocalhost = host === 'localhost' || host === '127.0.0.1' || host === '::1' || host === '[::1]';
    if (isLocalhost) {
      warnings.push(
        `IQ_CONNECTOR_URL points to ${parsed.hostname}, which refers to this cloud container itself. Deploy novatrade-ai/iq-connector separately and set its public HTTPS URL instead of localhost.`
      );
    }

    const normalized = raw.replace(/\/+$/, '');
    return {
      configured: true,
      url: normalized,
      urlValid: true,
      hadVarNamePrefix,
      isLocalhost,
      targetHost: parsed.host,
      tokenConfigured,
      warnings,
    };
  } catch {
    return {
      configured: true,
      url: null,
      urlValid: false,
      hadVarNamePrefix,
      isLocalhost: false,
      targetHost: null,
      tokenConfigured,
      warnings: [...warnings, 'IQ_CONNECTOR_URL is not a valid URL. Provide only the http(s) base URL.'],
    };
  }
}

export class IQOptionAdapter implements BrokerAdapter {
  readonly brokerId = 'iq_option';
  readonly brokerName = 'IQ Option';

  private getConfig(): ParsedIqConnectorConfig {
    return parseIqConnectorConfig();
  }

  private getHeaders(): Record<string, string> {
    const headers: Record<string, string> = { 'content-type': 'application/json' };
    const token = (process.env.IQ_CONNECTOR_TOKEN || '').trim();
    if (token) headers['x-connector-token'] = token;
    return headers;
  }

  private async requestConnector<T>(path: string, init: RequestInit = {}): Promise<T> {
    const cfg = this.getConfig();
    if (!cfg.configured) {
      throw new Error('IQ_CONNECTOR_URL is not configured in server environment.');
    }
    if (!cfg.urlValid || !cfg.url) {
      throw new Error(cfg.warnings[0] || 'IQ_CONNECTOR_URL is invalid.');
    }
    const res = await fetch(`${cfg.url}${path}`, {
      ...init,
      headers: { ...this.getHeaders(), ...(init.headers || {}) },
      signal: AbortSignal.timeout(6000),
    });
    const text = await res.text();
    let json: Record<string, unknown> = {};
    try {
      json = text ? (JSON.parse(text) as Record<string, unknown>) : {};
    } catch {
      json = { detail: text };
    }
    if (!res.ok) {
      const msg = String(json.detail || json.error || `Connector HTTP ${res.status}`);
      throw new Error(msg);
    }
    return json as T;
  }

  async getCapabilities(): Promise<BrokerCapabilities> {
    const cfg = this.getConfig();
    return {
      broker: this.brokerName,
      adapterInstalled: cfg.urlValid,
      authorisedApiVerified: false,
      connectorConfigured: cfg.urlValid,
      demoSupported: cfg.urlValid,
      realAccountSupported: false,
      orderExecutionSupported: false,
      historySupported: cfg.urlValid,
      environment: cfg.urlValid ? 'demo' : null,
      message: !cfg.configured
        ? 'IQ_CONNECTOR_URL is not set. Configure a private iq-connector instance for PRACTICE read-only inspection.'
        : !cfg.urlValid
          ? cfg.warnings[0] || 'IQ_CONNECTOR_URL is malformed.'
          : `IQ Option PRACTICE/read-only connector configured (${cfg.targetHost}). Real-money execution remains locked.`,
    };
  }

  async getStatus(): Promise<BrokerStatusSnapshot> {
    const caps = await this.getCapabilities();
    const cfg = this.getConfig();
    const checkedAt = new Date().toISOString();

    const baseDiagnostics: BrokerConnectorDiagnostics = {
      configured: cfg.configured,
      urlValid: cfg.urlValid,
      hadVarNamePrefix: cfg.hadVarNamePrefix,
      isLocalhost: cfg.isLocalhost,
      reachable: false,
      authenticated: false,
      credentialsConfigured: null,
      tokenConfigured: cfg.tokenConfigured,
      latencyMs: null,
      targetHost: cfg.targetHost,
      warnings: [...cfg.warnings],
      lastConnectorError: null,
    };

    if (!cfg.configured || !cfg.urlValid || !cfg.url) {
      return {
        ...caps,
        connected: false,
        executionEnabled: false,
        accountType: null,
        balance: null,
        currency: null,
        connectorUrlConfigured: cfg.configured,
        lastCheckedAt: checkedAt,
        limitations: IQ_LIMITATIONS,
        diagnostics: baseDiagnostics,
      };
    }

    const started = Date.now();
    try {
      const health = await this.requestConnector<{
        connected?: boolean;
        mode?: string;
        credentialsConfigured?: boolean;
        lastError?: string | null;
      }>('/health');
      const latencyMs = Date.now() - started;

      let balance: number | null = null;
      let accountType: string | null = health.connected ? 'PRACTICE' : null;
      let currency: string | null = null;

      if (health.connected) {
        try {
          const acct = await this.requestConnector<{
            accountType?: string;
            balance?: number;
            currency?: string;
          }>('/account');
          balance = typeof acct.balance === 'number' ? acct.balance : null;
          accountType = acct.accountType || 'PRACTICE';
          currency = acct.currency || 'USD';
        } catch {
          // Keep health connected state even if /account fails transiently
        }
      }

      const diagnostics: BrokerConnectorDiagnostics = {
        ...baseDiagnostics,
        reachable: true,
        authenticated: Boolean(health.connected),
        credentialsConfigured:
          typeof health.credentialsConfigured === 'boolean' ? health.credentialsConfigured : null,
        latencyMs,
        lastConnectorError: health.lastError ?? null,
      };

      const warningSuffix = cfg.warnings.length > 0 ? ` (${cfg.warnings[0]})` : '';
      return {
        ...caps,
        connected: Boolean(health.connected),
        executionEnabled: false,
        accountType,
        balance,
        currency,
        connectorUrlConfigured: true,
        lastCheckedAt: checkedAt,
        message: health.connected
          ? `Connected to IQ Option connector (${accountType || 'PRACTICE'} read-only, ${latencyMs}ms). Order execution locked.${warningSuffix}`
          : health.credentialsConfigured
            ? `IQ connector reachable (${latencyMs}ms); not authenticated (${health.lastError || 'click Connect Practice Session to initiate PRACTICE session'}).${warningSuffix}`
            : `IQ connector reachable (${latencyMs}ms), but IQ_EMAIL / IQ_PASSWORD are not set on the connector host.${warningSuffix}`,
        limitations: IQ_LIMITATIONS,
        diagnostics,
      };
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : 'connection failed';
      const diagnostics: BrokerConnectorDiagnostics = {
        ...baseDiagnostics,
        reachable: false,
        latencyMs: Date.now() - started,
        lastConnectorError: errMsg,
      };
      const warningHint = cfg.warnings.length > 0 ? ` ${cfg.warnings.join(' ')}` : '';
      return {
        ...caps,
        connected: false,
        executionEnabled: false,
        accountType: null,
        balance: null,
        currency: null,
        connectorUrlConfigured: true,
        lastCheckedAt: checkedAt,
        message: `IQ connector unreachable (${errMsg}).${warningHint}`,
        limitations: IQ_LIMITATIONS,
        diagnostics,
      };
    }
  }

  async connect(): Promise<{ connected: boolean; accountType: string | null; message: string }> {
    const res = await this.requestConnector<{ connected?: boolean; accountType?: string; mode?: string }>('/connect', {
      method: 'POST',
    });
    return {
      connected: Boolean(res.connected),
      accountType: res.accountType || res.mode || 'PRACTICE',
      message: res.connected
        ? 'Authenticated with IQ Option connector in PRACTICE read-only mode. Live orders remain disabled.'
        : 'IQ Option connector did not confirm an active session.',
    };
  }

  async disconnect(): Promise<{ connected: boolean; message: string }> {
    const cfg = this.getConfig();
    if (!cfg.configured || !cfg.urlValid) {
      return { connected: false, message: 'No valid IQ Option connector configured.' };
    }
    await this.requestConnector('/disconnect', { method: 'POST' });
    return { connected: false, message: 'Disconnected from IQ Option connector.' };
  }

  async getBalance() {
    const acct = await this.requestConnector<{ balance?: number; accountType?: string; currency?: string; source?: string }>('/account');
    return {
      balance: typeof acct.balance === 'number' ? acct.balance : null,
      accountType: acct.accountType || 'PRACTICE',
      currency: acct.currency || 'USD',
      source: acct.source || 'IQ_OPTION_UNOFFICIAL',
    };
  }

  async getAssets(): Promise<{ assets: BrokerAssetInfo[]; count: number; source: string }> {
    const res = await this.requestConnector<{ assets?: BrokerAssetInfo[]; count?: number; source?: string }>('/assets');
    return {
      assets: Array.isArray(res.assets) ? res.assets : [],
      count: typeof res.count === 'number' ? res.count : 0,
      source: res.source || 'IQ_OPTION_UNOFFICIAL',
    };
  }

  async getCandles(symbol: string, intervalSeconds = 60, count = 100): Promise<{ candles: BrokerCandle[]; source: string; note?: string }> {
    const res = await this.requestConnector<{ candles?: BrokerCandle[]; source?: string; note?: string }>('/candles', {
      method: 'POST',
      body: JSON.stringify({ symbol, interval: intervalSeconds, count }),
    });
    return {
      candles: Array.isArray(res.candles) ? res.candles : [],
      source: res.source || 'IQ_OPTION_UNOFFICIAL',
      note: res.note,
    };
  }

  async getTradeHistory(): Promise<BrokerTradeHistoryResult> {
    const cfg = this.getConfig();
    if (!cfg.configured || !cfg.urlValid) {
      return {
        supported: false,
        trades: [],
        note: cfg.warnings[0] || 'IQ_CONNECTOR_URL is not configured.',
      };
    }
    const res = await this.requestConnector<BrokerTradeHistoryResult>('/history');
    return {
      supported: Boolean(res.supported),
      trades: Array.isArray(res.trades) ? res.trades : [],
      note: res.note || 'Retrieved from IQ Option connector.',
    };
  }
}
