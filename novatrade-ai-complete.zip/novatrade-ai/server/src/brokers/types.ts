/**
 * Extensible broker adapter contract.
 * Implement only against a documented, authorised API or explicitly sandboxed PRACTICE connector.
 */
export type BrokerEnvironment = 'demo' | 'real';

export interface BrokerCapabilities {
  broker: string;
  adapterInstalled: boolean;
  authorisedApiVerified: boolean;
  connectorConfigured: boolean;
  demoSupported: boolean;
  realAccountSupported: boolean;
  orderExecutionSupported: boolean;
  historySupported: boolean;
  environment: BrokerEnvironment | null;
  message: string;
}

export interface BrokerConnectorDiagnostics {
  configured: boolean;
  urlValid: boolean;
  hadVarNamePrefix: boolean;
  isLocalhost: boolean;
  reachable: boolean;
  authenticated: boolean;
  credentialsConfigured: boolean | null;
  tokenConfigured: boolean;
  latencyMs: number | null;
  targetHost: string | null;
  warnings: string[];
  lastConnectorError: string | null;
}

export interface BrokerStatusSnapshot extends BrokerCapabilities {
  connected: boolean;
  executionEnabled: boolean;
  accountType: string | null;
  balance: number | null;
  currency: string | null;
  connectorUrlConfigured: boolean;
  lastCheckedAt: string;
  limitations: string[];
  diagnostics?: BrokerConnectorDiagnostics;
}

export interface BrokerAssetInfo {
  symbol: string;
  category: string;
  open: boolean;
}

export interface BrokerCandle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface BrokerTradeHistoryResult {
  supported: boolean;
  trades: Array<Record<string, unknown>>;
  note: string;
}

export interface BrokerAdapter {
  readonly brokerId: string;
  readonly brokerName: string;
  getCapabilities(): Promise<BrokerCapabilities>;
  getStatus(): Promise<BrokerStatusSnapshot>;
  connect?(): Promise<{ connected: boolean; accountType: string | null; message: string }>;
  disconnect?(): Promise<{ connected: boolean; message: string }>;
  getBalance?(): Promise<{ balance: number | null; accountType: string | null; currency: string | null; source: string }>;
  getAssets?(): Promise<{ assets: BrokerAssetInfo[]; count: number; source: string }>;
  getCandles?(symbol: string, intervalSeconds: number, count: number): Promise<{ candles: BrokerCandle[]; source: string; note?: string }>;
  getTradeHistory?(): Promise<BrokerTradeHistoryResult>;
  placeOrder?(_input: {
    environment: BrokerEnvironment;
    symbol: string;
    direction: 'CALL' | 'PUT';
    amount: number;
    expirySeconds: number;
    idempotencyKey: string;
  }): Promise<{ brokerOrderId: string; status: string }>;
}
