# IQ Option integration status

Current state: adapter contract only; no account connection or order execution.

Do not implement private WebSocket endpoints, browser scraping, credential replay or session-cookie capture. Do not request a user's broker password or OTP in this application.

A future integration requires:
- broker-published API documentation;
- written permission/terms allowing the intended third-party use;
- confirmation that the user's account and jurisdiction are eligible;
- documented authentication (prefer OAuth or scoped API keys);
- a read-only market/account phase before order placement;
- demo validation, then separately opted-in real-account permissions;
- server-side risk controls, audit trails, idempotency and emergency stop.

The adapter interface in `types.ts` defines the boundary. `iqOption.ts` intentionally reports unsupported capabilities until those requirements are met.
