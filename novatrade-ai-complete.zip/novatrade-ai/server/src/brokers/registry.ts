import type { BrokerAdapter } from './types.ts';
import { IQOptionAdapter } from './iqOption.ts';

export interface BrokerCatalogEntry {
  id: string;
  name: string;
  status: 'INTEGRATED_READONLY' | 'PLANNED';
  description: string;
  realExecutionEnabled: boolean;
}

export class BrokerRegistry {
  private readonly adapters = new Map<string, BrokerAdapter>();

  constructor() {
    this.register(new IQOptionAdapter());
  }

  register(adapter: BrokerAdapter) {
    this.adapters.set(adapter.brokerId, adapter);
  }

  get(brokerId: string): BrokerAdapter | undefined {
    return this.adapters.get(brokerId);
  }

  listCatalog(): BrokerCatalogEntry[] {
    return [
      {
        id: 'iq_option',
        name: 'IQ Option',
        status: 'INTEGRATED_READONLY',
        description: 'Connected via IQ_CONNECTOR_URL (PRACTICE / read-only diagnostics, balance, assets, candles, history). Real-money execution locked.',
        realExecutionEnabled: false,
      },
      {
        id: 'deriv',
        name: 'Deriv WebSocket API',
        status: 'PLANNED',
        description: 'Extensible adapter slot for documented OAuth / API-token binary & CFD execution.',
        realExecutionEnabled: false,
      },
      {
        id: 'oanda',
        name: 'OANDA v20 REST',
        status: 'PLANNED',
        description: 'Extensible adapter slot for regulated FX spot & CFD practice/live accounts.',
        realExecutionEnabled: false,
      },
    ];
  }
}
